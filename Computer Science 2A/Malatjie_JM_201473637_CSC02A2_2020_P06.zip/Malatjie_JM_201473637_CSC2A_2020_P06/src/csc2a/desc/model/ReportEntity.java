package csc2a.desc.model;

/**
 * 
 * @author JM Malatjie
 *
 */
public class ReportEntity {
	
	//Declaring variables
	private int X;
	private int Y;
	private Event event;
	
	/**
	 * Parameterised constructor
	 * @param x coordinate of event location
	 * @param y coordinate of event location
	 * @param event the Event parameter
	 */
	public ReportEntity(int y, int x,Event event)
	{
		X = x;
		Y = y;
		this.event = event;
	}

	//get method for variable X
	public int getX() {
		return X;
	}

	//Set method for variable X
	public void setX(int x) {
		X = x;
	}

	//get method for variable Y
	public int getY() {
		return Y;
	}

	//set method for variable Y
	public void setY(int y) {
		Y = y;
	}

	//get method for event
	public Event getEvent() {
		return event;
	}
	
	

}
