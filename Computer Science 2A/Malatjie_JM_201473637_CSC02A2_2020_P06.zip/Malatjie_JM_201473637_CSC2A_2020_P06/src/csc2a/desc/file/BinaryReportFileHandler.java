package csc2a.desc.file;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import csc2a.desc.model.Crisis;
import csc2a.desc.model.ReportEntity;

/**
 * 
 * @author JM Malatjie
 *
 */
public class BinaryReportFileHandler 
{	
	/**
	 * passing the file as a parameter
	 * @param file Binary file from the data folder
	 * @return reportEntity array
	 */
	public static ReportEntity[] readCrisisReports(File file)
	{
		DataInputStream dataIn = null; 
		Crisis crisis = null;
		ReportEntity[] reportEntity = null;
		//reportEntity = new ReportEntity[2];
		
		try 
		{
			FileInputStream input = new FileInputStream(file);
			
			BufferedInputStream buffIn = new BufferedInputStream(input);
			
			dataIn = new DataInputStream(buffIn);
			
			String CR_ID = dataIn.readUTF(); //Crisis ID from the Binary file

			//Accessing the appropriate crisis text file
			File f = new File("data/Crisis Messages/"+CR_ID+".txt");
			crisis = CrisisFileHandler.readCrisis(f);
			
			//resizing the array
			reportEntity = new ReportEntity[crisis.getEvents().length];
			
			//variable to make sure that EOFexception is not callsed
			int bytes = dataIn.available();
			
			while(bytes != 0)
			{
				
				String EV_ID = dataIn.readUTF(); //Event_ID from the binary file
				int Y = dataIn.readInt(); 
				int X = dataIn.readInt();
				
				/*
				 * for loop to make sure that the correct Event with it's coordinates are stored in the Report Entity 
				 */
				for(int i = 0; i < crisis.getEvents().length; i++) 
				{ 
					String eventId = crisis.getEvent(i).getEventID();
					
					if(EV_ID.equals(eventId) ) 
					{ 
						reportEntity[i] = new ReportEntity(Y,X,crisis.getEvent(i)); 
					} 
				}
				
				bytes = dataIn.available();
			}

		}
		catch (FileNotFoundException e) {
		
			
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(dataIn != null)
			{
				try 
				{
					dataIn.close(); //closing the file
				} 
				catch (IOException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return reportEntity;		
	}
}
