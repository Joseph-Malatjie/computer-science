import java.util.ArrayList;

import csc2a.desc.thread.ComputeCostExecutor;

public class Main {

	public static void main(String[] args) 
	{
		 ArrayList<Integer> disaster_ID = new ArrayList<Integer>();
		
		 /*
		  * Adding ID's to the ArrayList
		  */
		 disaster_ID.add(1);
		 disaster_ID.add(10);
		 disaster_ID.add(15);
		 disaster_ID.add(23);
		 disaster_ID.add(25);
		 disaster_ID.add(26);
		 disaster_ID.add(66);
		 disaster_ID.add(78);
		 disaster_ID.add(89);
		 disaster_ID.add(190);
		 
		 //instantiating the ComputeCostExecutor
		 ComputeCostExecutor costExecutor = new ComputeCostExecutor(disaster_ID);
		 
		 //creating a new thread
		 Thread thread = new Thread(costExecutor);
		 
		 ///Starting the thread
		 thread.start();
		 
		 try 
		 {
			 //Joining the threads
			thread.join();
		 } 
		 catch (InterruptedException e)
		 {
			e.printStackTrace();
		 }
		 
		 System.out.println("\nAll tasks are complete");

	}

}
