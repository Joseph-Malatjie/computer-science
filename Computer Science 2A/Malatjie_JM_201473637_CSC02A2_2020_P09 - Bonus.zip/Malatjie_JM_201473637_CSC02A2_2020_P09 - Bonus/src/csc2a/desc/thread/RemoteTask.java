package csc2a.desc.thread;

import csc2a.desc.remote.RemoteReportProcessor;

/**
 * 
 * @author JM Malatjie
 *
 */
public class RemoteTask implements Runnable
{

	private int disaster_ID;
	private double cost = 0.0;
	
	/**
	 * Constructor
	 * @param disaster_ID parameter of the constructor
	 */
	public RemoteTask(int disaster_ID)
	{
		this.disaster_ID = disaster_ID;
		cost = RemoteReportProcessor.processReportCost(disaster_ID);
	}
	
	@Override
	public void run() 
	{
		try
		{
			Thread.sleep(1000);
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		
		System.out.printf("\n%s: "+"D$"+"%s"+"M"+"\n",disaster_ID,cost);

	}
	
	//accessor method
	public int getDisaster_ID() 
	{
		return disaster_ID;
	}
	
	public double getCost()
	{
		return cost;
	}

}
