package csc2a.desc.ui;

import csc2a.desc.model.ReportEntity;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * 
 * @author JM Malatjie
 *
 */
public class ReportCanvas extends Canvas{
	
	GraphicsContext gc = null;
	ReportEntity[] reObjects = null;
	
	/*
	 * constructor
	 */
	public ReportCanvas()
	{
		this.setWidth(15*41);
		this.setHeight(15*40);
		
	}
	
	/**
	 * Storing an array of ReportEntity objects
	 * @param reObjects ReportEntity array
	 */
	public void setObjects(ReportEntity[] reObjects)
	{
		this.reObjects = reObjects;
		redrawCanvas();
	}
	
	/*
	 * drawing a virtual satellite view of the reported Crisis area
	 */
	private void redrawCanvas()
	{
		gc = this.getGraphicsContext2D();
		gc.setFill(Color.TEAL);
		gc.fillRect(0, 0, 15*41, 15*40);
			
		for(int i = 0; i < reObjects.length; i++)
		{
			//X and Y coordinates
			int Y = reObjects[i].getY();
			int X = reObjects[i].getX();
			
			//creating a grid for each event 
			for(int x = X; x < 3+X; x++)
			{
				for(int y = Y; y < 3+Y; y++)
				{
					  gc.setFill(Color.BURLYWOOD); 
					  gc.fillRect(x * 41, y * 40, 39, 39); 
				}
			}
			gc.setFill(Color.BLACK);
			gc.fillText(reObjects[i].getEvent().getEventID(), (X*41), (Y*40) + 25); //displaying the eventID on the grid
		}
		
	
	}
}
