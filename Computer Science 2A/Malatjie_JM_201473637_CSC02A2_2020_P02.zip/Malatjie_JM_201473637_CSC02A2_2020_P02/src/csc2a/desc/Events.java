package csc2a.desc;
/**
 * 
 * @author Malatjie JM
 *
 */
public class Events {
	
	/**
	 * declaring variables
	 */
	private  String Event_ID;
	private  String Event_Name;
	private  String Event_Category;
	private  int Event_Severity;
	private  boolean Event_Responded;
	
	/**
	 * 
	 * @return
	 */
	public  String getEvent_ID() {
		return Event_ID;
	}
	
	/**
	 * 
	 * @param event_ID
	 */
	public void setEvent_ID(String event_ID) {
		Event_ID = event_ID;
	}
	
	/**
	 * 
	 * @return
	 */
	public  String getEvent_Name() {
		return Event_Name;
	}
	
	/**
	 * 
	 * @param event_Name
	 */
	public void setEvent_Name(String event_Name) {
		Event_Name = event_Name;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getEvent_Category() {
		return Event_Category;
	}
	
	/**
	 * 
	 * @param event_Category
	 */
	public void setEvent_Category(String event_Category) {
		Event_Category = event_Category;
	}
	
	/**
	 * 
	 * @return
	 */
	public int getEvent_Severity() {
		return Event_Severity;
	}
	
	/**
	 * 
	 * @param event_Severity
	 */
	public void setEvent_Severity(int event_Severity) {
		Event_Severity = event_Severity;
		Crisis.total = totalSeverity(Event_Severity);
	}
	
	/**
	 * 
	 * @param severity
	 * @return
	 */
	public int totalSeverity(int severity)
	{

		int total = 0;
		total = total + severity; 
		return total;
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean isEvent_Responded() {
		return Event_Responded;
	}
	
	/**
	 * 
	 * @param event_Responded
	 */
	public void setEvent_Responded(boolean event_Responded) {
		Event_Responded = event_Responded;
	}
	
}
