package csc2a.desc;

/**
 * 
 * @author Malatjie JM
 *
 */
public class Crisis {

	/**
	 * declaring variables
	 */
	private static String Crisis_ID;
	private static String Crisis_Name;
	private static String Crisis_Team;
	private static double Crisis_Priority;
	public Events[] Crisis_Events = new Events[2];
	public static int total;
	private double average;
	
/**
 * Mutators and accessors	
 */
	/**
	 * getting the crisis_D
	 * @return a string 
	 */
	public String getCrisis_ID() {
		return Crisis_ID;
	}
	
	/**
	 * storing crisis_ID
	 * @param crisis_ID
	 */
	public void setCrisis_ID(String crisis_ID) {
		Crisis_ID = crisis_ID;
	}
	
	/**
	 * getting the Crisis_Name
	 * @return a string value 
	 */
	public String getCrisis_Name() {
		return Crisis_Name;
	}
	
	/**
	 * storing the Crisis_Name
	 * @param crisis_Name
	 */
	public void setCrisis_Name(String crisis_Name) {
		Crisis_Name = crisis_Name;
	}
	
	/**
	 * retrieving the stored name of crisis team
	 * @return a string value
	 */
	public String getCrisis_Team() {
		return Crisis_Team;
	}
	
	/**
	 * storing the name of the crisis team
	 * @param crisis_Team a single parameter for the method
	 */
	public void setCrisis_Team(String crisis_Team) {
		Crisis_Team = crisis_Team;
	}
	
	/**
	 * 
	 * @return double value of Crisis_Priority
	 */
	public double getCrisis_Priority() {
		return Crisis_Priority;
	}
	
	/**
	 * calculating average
	 * @return average
	 */
	private double crisis_priority()
	{
		average = total/2;
		return average;
	}
	
	/**
	 * storing the value of Crisis_priority
	 */
	public void setCrisis_Priority() {
		
		Crisis_Priority = crisis_priority();
	}
	
	/**
	 * getting crisis_events information
	 * @return Crisis_Events
	 */
	public Events[] getCrisis_Events() {
		return Crisis_Events;
	}
	
	/**
	 * setting up crisis_events information
	 * @param crisis_Events
	 */
	public void setCrisis_Events(Events[] crisis_Events) {
		Crisis_Events = crisis_Events;
	}
	
	
}
