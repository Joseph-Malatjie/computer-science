/**
 * 
 * @author Malatjie JM
 *
 */
import csc2a.desc.Crisis;
import csc2a.desc.Events;
import java.util.Scanner;

public class Main {

	/**
	 * the main method of the main class
	 * @param args
	 */
	public static void main(String[] args) {
		
		/**
		 * creating a scanner variable for the user input
		 */
		Scanner input = new Scanner(System.in);

		/**
		 * creating a crisis object
		 */
		Crisis[] crisis = new Crisis[2];
		
		for(int i = 0; i < 2; i++) {
			
			/**
			 * instantiating the crisis object
			 */
			crisis[i] = new Crisis();
			
			System.out.println("Please enter Crisis ID for crisis " + (i+1));
			crisis[i].setCrisis_ID(input.nextLine());
		
			System.out.println("Please enter Crisis Name for crisis "+ (i+1));
			crisis[i].setCrisis_Name(input.nextLine());
		
			System.out.println("Please enter the Crisis team for crisis " + (i+1));
			crisis[i].setCrisis_Team(input.nextLine());
			
			/**
			 * creating events object
			 */
			Events[] events = new Events[2];
			
			for(int j = 0; j < 2; j++ ) {
				
				/**
				 * instantiating the events object
				 */
				events[j] = new Events();
				
				System.out.println("Please enter Event ID for event " + (j+1));
				events[j].setEvent_ID(input.nextLine());
				
				System.out.println("Please enter the Event Name for event " + (j+1));
				events[j].setEvent_Name(input.nextLine());
				
				System.out.println("Please enter event category for event " + (j+1));
				events[j].setEvent_Category(input.nextLine());
				
				System.out.println("Please enter event severity for event " + (j+1));
				int severity = Integer.parseInt(input.nextLine());
				events[j].setEvent_Severity(severity);
				
				System.out.println("Is the event been responded to? True or False for event " + (j+1));
				events[j].setEvent_Responded(Boolean.parseBoolean(input.nextLine()));				
				
			}
			
			crisis[i].setCrisis_Events(events);			
		}
		
		for(int i = 0; i < 2; i++)
		{
			System.out.println("\n************************************************************************************************************\n"+
				"CRISIS" +
				"\n**********************************************************************************************************\n"+
				"\nCrisis_ID "+(i+1)+": " + crisis[i].getCrisis_ID() + "\nCrisis_Name "+(i+1)+": " + crisis[i].getCrisis_Name() + 
			   "\nCrisis_Team "+(i+1)+": " + crisis[i].getCrisis_Team() + "\nCrisis_Priority "+(i+1)+": " + crisis[i].getCrisis_Priority() +
			    "\n.....................................................................................................  ");
		
			for(int j = 0; j < 2; j++)
			{
				System.out.println("\nCRISIS EVENTS \n" + "..............................................................................................." +
								    "\nEvent_ID "+(j+1)+": " + crisis[i].Crisis_Events[j].getEvent_ID() + "\nEvent_Name "+(j+1)+": " + crisis[i].Crisis_Events[j].getEvent_Name() +
								    "\nEvent_Category  "+(j+1)+": " + crisis[i].Crisis_Events[j].getEvent_Category() + "\nEvent_Severity "+(j+1)+": " + crisis[i].Crisis_Events[j].getEvent_Severity() +
								    "\nEvent_Responde "+(j+1)+": " + crisis[i].Crisis_Events[j].isEvent_Responded()+ "\n");
			}
		}
		
		input.close();
	}

}
