package csc2a.desc.thread;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 
 * @author JM Malatjie
 *
 */

public class ComputeCostExecutor implements Runnable{
	
	private ArrayList<Integer> disaster_ID = new ArrayList<Integer>();

	/**
	 * 
	 * @param disaster_ID arraylist id's
	 */
	public ComputeCostExecutor(ArrayList<Integer> disaster_ID)
	{
		this.disaster_ID = disaster_ID;
	}
	
	@Override
	public void run() 
	{
		ExecutorService threadPool = Executors.newCachedThreadPool();
		
		//Creating and running the tasks
		for(int i = 0; i < disaster_ID.size(); i++)
		{
			Runnable remoteTask = new RemoteTask(disaster_ID.get(i));
			threadPool.execute(remoteTask);
		}
		
		threadPool.shutdown();
		
		while(!threadPool.isTerminated())
		{
			//wait
		}
		
		//indicates that the tasks are done
		System.out.println("\nComputeCostExecuter is Done!");
	}

	//ArrayList accessor method
	public ArrayList<Integer> getDisaster_ID() {
		return disaster_ID;
	}

}
