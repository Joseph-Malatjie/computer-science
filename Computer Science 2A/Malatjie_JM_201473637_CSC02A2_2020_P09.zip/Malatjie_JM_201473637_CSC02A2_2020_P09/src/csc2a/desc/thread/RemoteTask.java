package csc2a.desc.thread;

import csc2a.desc.remote.RemoteReportProcessor;

/**
 * 
 * @author JM Malatjie
 *
 */
public class RemoteTask implements Runnable
{

	private int disaster_ID;
	
	/**
	 * Constructor
	 * @param disaster_ID parameter of the constructor
	 */
	public RemoteTask(int disaster_ID)
	{
		this.disaster_ID = disaster_ID;
	}
	
	@Override
	public void run() 
	{
		double cost = RemoteReportProcessor.processReportCost(disaster_ID);
		System.out.printf("\n%s: "+"D$"+"%s"+"M"+"\n",disaster_ID,cost);
	}

	//accessor method
	public int getDisaster_ID() 
	{
		
		return disaster_ID;
	}
	
	

}
