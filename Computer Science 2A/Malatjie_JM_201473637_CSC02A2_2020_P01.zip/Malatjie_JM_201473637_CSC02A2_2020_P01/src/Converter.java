/**
Author: Joseph Malatjie
*/

import java.util.Scanner;

public class Converter 
{
	/** Constructor */
	public Converter()
	{
		clearMessage = " ";
		secretMessage = " ";
	}
	
	/** Inner state for the message */
	private static String clearMessage;
	
	/** Inner state for the secrete message */
	private static String secretMessage;
	
	/** An array representing all of the alpha numeric characters that can be converted to secret characters */
	static String[] text = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U",
				            "V","W","X","Y","Z","1","2","3","4","5","6","7","8","9","0"," "};
	
	/** Letters relating to the array above (will be used as a substitution cypher) */
	static String[] scram = {"D", "U", "P", "1", "Q", "C", "I", "O", "5","7", "Z", "6", "V", "8", "W", "H", "T", "L",
                             "E", "0", "M", "J", "B", "4", "G", "9", "X","N", "3", " ", "2", "R", "Y", "K","S", "F", "A"};
	
	/** Method to encode a message */
	public static String Encode(String message)
	{
		clearMessage = ToUpper(message); /** Make the message upper case */
		
		for(int i = 0; i < message.length(); i++)
		{
			int index = -1; /** stores the index of the character in the text array to be correlated to the secret array */
			char temp = clearMessage.charAt(i); /** Get the character out of the string */
			
			/** Search the text array for the index of the character */
			for(int j = 0; j < text.length; j++)
			{
				if(text[j].charAt(0) == temp)
				{ 
					/** Compare every character in text to the temp character */
					index = j;
				}
			}
			
			if(index != -1)
			{ 
				/** Make sure we have a valid character */
				secretMessage += scram[index]; /** Convert the character to secret characters */
			}
		}
		return secretMessage;
	}
	
	/** Method to decode message */
	public static String Decode(String secret)
	{
		secretMessage = ToUpper(secret); /** Make the message upper case */
		/** Begin encoding message */
		for(int i = 0; i < secret.length(); i++)
		{
			int index = -1; /**Stores the index of the character in the text array oto be correlated to the secret array */
			char temp = secretMessage.charAt(i); /** Get the character out of the string */
				
			/** Search the text array for the index of the character */
			for(int j = 0; j < text.length; j++)
			{
				if(scram[j].charAt(0) == temp)
				{ 
					/** Compare every character in text to the temp character */
					index = j;
				}
			}
			if(index != -1)
			{ 
				/** Make sure we have a valid character */
				clearMessage += text[index]; /** Convert the character to normal characters */
			}
		}
		return clearMessage;
	}
	
	/** Accessors and Mutators */
	public static String getClearMessage()
	{
		return clearMessage;
	}
	
	public static String getSecretMessage()
	{
		return secretMessage;
	}
	
	public static void setClearMessage(String msg)
	{
		clearMessage = msg;
	}
	
	public static void setSecretMessage(String sec)
	{
		secretMessage = sec;
	}
	
	/** Converts all characters to upper case */
	private static String ToUpper(String msg)
	{
		return msg.toUpperCase();
	}
	
	public static void main(String[] args)
	{
		/**Stores the crisis message to be encoded/decoded */
		String message= ""; 
		
		/** Stores the result of encoding/decoding */
		String result = ""; 

		/** Stores the options asked to the user */
		String encode = "";  
		
		/** Instance of Converter */
		Converter converter = new Converter();
		
		/** creating a Scanner object */
		Scanner input = new Scanner(System.in);
		
		/** Displays the output message to the user */
		System.out.println("Would you like to Encode a Crisis Message (E) or Decode a scrambled Crisis Message (D)?");
		
		/** Reading user input and storing it in the encode variable*/  
		encode = input.nextLine();
		
		if(!encode.equalsIgnoreCase("E"))
		{
			/**Encode the inputted crisis message*/
			System.out.println("Please enter the Crisis Message to encode:");
			message = input.nextLine();
			
			/** Encode */
			
			/** Encoding the crisis message using the Converter */
			result = converter.Encode(message); 
			System.out.println("Entered Clear-text Crisis Message: "+ message);
			System.out.println("Encoded Crisis Message:" +
			"\n_________________________________\n" +
			 result +
			 "\n_________________________________");
		}
		else
		{
			
        /** Decoding a scrambled Crisis message into Clear-Text */
        System.out.println("Please enter Encoded Crisis Message to Decode:");
        message = input.nextLine();
		
        /** Decode */
		
		/** Decoding the Crisis Message using Converter */
        result = converter.Decode(message); 
        System.out.println("Entered Encoded Crisis Message: " + message);
        System.out.println("Decoded Crisis Message:" +
        "\n_________________________________\n" +
        result +
        "\n_________________________________");
    }
	}
	
}