package csc2a.desc.file;
//Package Imports
import csc2a.desc.model.Crisis;
import csc2a.desc.model.Event;
import csc2a.desc.model.InvalidEvent;
import csc2a.desc.model.ValidEvent;
import csc2a.desc.model.E_EVENT_CATEGORY;
//Other Imports
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 * File Handling Class used to load Crises and their Events from file
 * @author Mr Greaves
 * @author Joseph Malatjie
 * (Dystopian Emergency Services Council)
 * @version P03
 */
public class CrisisFileHandler {	
	/* Regex that will match the Crisis information
	 * |  CR_ID  |  |CR_NAME|  | *CR_Team*          |
	 * v		 v  v 	    v  v                    v
	 * [A-Z0-9]{6}\t(\w+\s?)+\t\*([A-Z]?[a-z]+\s?)+\*
	 * OR a Basic Regex:
	 * [A-Z0-9]{6}\t(\w+\s?)+\t\*(\w+\s?)+\*
	 */
	//Decent Regex
	private static final Pattern crisisHeaderPattern = Pattern.compile("[A-Z0-9]{6}\\t(\\w+\\s?)+\\t\\*([A-Z]?[a-z]+\\s?)+\\*");
	
	/* Regex that will match the Event information
	 * |  EV_ID  |  |  EV_NAME       |  |[EV_CATEGORY@EV_SEVERITY]                                               |  |EV_RESPONDED|
	 * v         v  v                v  v                                                                        v  v            v
	 * [A-Z0-9]{6}\t([A-Z]?[a-z]+\s?)+\t\[(DISASTER|HUMANITARIAN|WAR|FAMINE|PEACEKEEPING|TRAINING)@(10|[0-9]{1})\]\t(true|false)\t[1-9]{1}
	 *  OR a Basic Regex:
	 * [A-Z0-9]{6}\t(\w+\s?)+\[[A-Z]+@\d{1,2}\]\t[a-z]+
	 */
	private static final Pattern eventPattern = Pattern.compile("[A-Z0-9]{6}\\t([A-Z]?[a-z]+\\s?)+\\t\\[(DISASTER|HUMANITARIAN|WAR|FAMINE|PEACEKEEPING|TRAINING)@(10|[0-9]{1})\\]\\t(true|false)\\t[1-9]{1}");
	/**
	 * Method to read a crisis message file and create a Crisis object
	 * @param crisisFile The file to be opened
	 * @return a Crisis or null if there is a major problem
	 */
	public static Crisis readCrisis(File crisisFile) 
	{
		//Create return reference
		Crisis crisisHappening = null;

		//Check if the file is valid
		if(!crisisFile.exists()) {
			System.err.println("Error: File is not valid");
			return crisisHappening;
		}
		
		//Start Processing file
		Scanner scCrisis = null;
		try {
			//Open file
			scCrisis = new Scanner(crisisFile);
			//Check file isn't empty
			if(!scCrisis.hasNext()) {
				System.err.println("Error: File is empty");
				return crisisHappening;
			}
			/*
			 * Get Crisis Information
			 * Format:
			 * CR_ID CR_NAME *CR_Team*
			 */
			String crisisHeader = scCrisis.nextLine();
			//Validate with Regex
			Matcher crisisHeaderMatcher = crisisHeaderPattern.matcher(crisisHeader);
			//If Regex fails to match, return a null Crisis
			if(!crisisHeaderMatcher.matches()) {
				System.err.format("Crisis Header does not match:\r%s\n", crisisHeader);
				return crisisHappening;
			}
			//Breakup the header
			StringTokenizer crisisHeaderTokenizer = new StringTokenizer(crisisHeader, "\t");
			String crisisID 	= crisisHeaderTokenizer.nextToken();
			String crisisName 	= crisisHeaderTokenizer.nextToken();
			String crisisTeam	= crisisHeaderTokenizer.nextToken();
			//Get rid of the * *
			crisisTeam = crisisTeam.substring(1,crisisTeam.length()-1);
			System.out.printf("***Crisis Header***\nC-ID: %S\nC-Nm: %s\nC-Tm: %s\n\n", crisisID, crisisName, crisisTeam);
			//Create the Crisis
			crisisHappening = new Crisis(crisisID, crisisName, crisisTeam);
			/*
			 * Get Events
			 */
			while(scCrisis.hasNext()) 
			{
				String eventLine = scCrisis.nextLine();
				//Validate line with Regex
				Matcher eventMatcher = eventPattern.matcher(eventLine);
				//If the Regex fails to match, output on error stream
				if(!eventMatcher.matches()) {
					System.err.format("Event does not match:\r%s\n", eventLine);
				}else {
					//Create Event
					Event event = makeEventFromString(eventLine);
					crisisHappening.addEvent(event);
				}
			}			
			//Recompute Crisis Priority
			crisisHappening.computeCrisisPriority();
		} catch(FileNotFoundException fnfex) {
			System.err.format("Error: File %s does not exist%", crisisFile.getAbsolutePath());
		} finally {
			//Close the file
			if(scCrisis != null) {
				scCrisis.close();
			}
		}
		return crisisHappening;
	}
	/**
	 * Method to create and Event instance from a matched String
	 * @param eventLine String matched by the Regex
	 * @return An Event instance
	 */
	private static Event makeEventFromString(String eventLine) {
		/*
		 * Format of Event:
		 * EV_ID EV_NAME [EV_CATEGORY@EV_SEVERITY] EV_RESPONDED
		 */
		StringTokenizer eventTokens = new StringTokenizer(eventLine, "\t");
		String eID = eventTokens.nextToken();
		String eName = eventTokens.nextToken();
		String tempCatAndSev = eventTokens.nextToken();
		boolean eResponded = Boolean.parseBoolean(eventTokens.nextToken());
		int eVerification = Integer.parseInt(eventTokens.nextToken());
		
		//Get Category and Severity from tempCatAndSev
		//Remove [and]
		tempCatAndSev = tempCatAndSev.substring(1, tempCatAndSev.length()-1);
		//Split at the @
		String[] parts = tempCatAndSev.split("@");
		E_EVENT_CATEGORY eCategory = E_EVENT_CATEGORY.valueOf(parts[0]);
		int eSeverity = Integer.parseInt(parts[1]);
		//Print Event
		//System.out.printf("***Event***\neID: %S\neNm: %s\neCat: %s\neSev: %d\neRes: %b\n", eID, eName, eCategory.toString(), eSeverity, eResponded);
		
		//Create Event
		if(Event.verify(eVerification) == true )
		{
			InvalidEvent invalidEvent = new InvalidEvent(eName, eID, eCategory, eSeverity, eResponded,eVerification);
			invalidEvent.issueReport(1, 2);
			return invalidEvent;
		}
		else
		{
			ValidEvent validEvent = new ValidEvent(eName, eID, eCategory, eSeverity, eResponded,eVerification);
			validEvent.issueReport(2, 3);
			return validEvent;
		}
		
	}
}
