package csc2a.desc.model;

/**
 * 
 * @author Joseph Malatjie
 *
 */
public interface iReportable {
	
	/**
	 * method prototype
	 * @param X
	 * @param Y
	 */
	public void issueReport(int X, int Y);

}
