package csc2a.desc.model;
/**
 * Class representing a Crisis Happening
 * @author Mr Greaves
 * (Dystopian Emergency Services Council)
 * @version P03
 */
public class Crisis {
	/*
	 * Attributes
	 */
	private final String crisisID;
	private String crisisName;
	private String crisisTeam;
	private int crisisPriority; //Computed from the Events
	private Event[] crisisEvents;
	
	/**
	 * Default Constructor
	 */
	public Crisis() {
		crisisID 		= "NoID";
		crisisName 		= "NoName";
		crisisTeam 		= "NoTeam";
		crisisPriority 	= 0;		
	}
	/**
	 * Parameterized Constructor
	 * @param id Unique ID of the Crisis
	 * @param name Name of the Crisis
	 * @param team Name of the Team handling the Crisis
	 */
	public Crisis(String id, String name, String team) {
		crisisID 		= id;
		crisisName 		= name;
		crisisTeam 		= team;
		crisisPriority 	= 0;
		crisisEvents = new Event[0];
	}
	
	/**
	 * Accessor for Events in Crisis
	 * @param index The index to return
	 * @return Event at index or null if out of bounds
	 */
	public Event getEvent(int index) {
		if(index < 0 || index >= crisisEvents.length) {
			System.err.println("Invalid index: " + index);
			return null;
		}
		return crisisEvents[index];
	}
	
	/**
	 * Accessor for all Events in Crisis
	 * @return An Array of all Events in the Crisis
	 */
	public Event[] getEvents() {
		return crisisEvents;
	}
	/**
	 * Accessor for Crisis ID
	 * @return Crisis ID
	 */
	public String getCrisisID() {
		return crisisID;
	}
	/**
	 * Accessor for Crisis Name
	 * @return Crisis Name
	 */
	public String getCrisisName() {
		return crisisName;
	}
	/**
	 * Accessor for Crisis Team
	 * @return Crisis Team
	 */
	public String getCrisisTeam() {
		return crisisTeam;
	}
	/**
	 * Accessor for Crisis Priority
	 * @return Crisis Priority
	 */
	public int getCrisisPriority() {
		return crisisPriority;
	}
	/**
	 * Accessor for Number of Crisis Events
	 * @return Number of Crisis Events
	 */
	public int getNumCrisisEvents() {
		return crisisEvents.length;
	}
	
	/**
	 * Mutator for Crisis Name
	 * @param name Crisis Name
	 */
	public void setCrisisName(String name) {
		crisisName = name;
	}
	/**
	 * Mutator for Crisis Team
	 * @param team Crisis Team
	 */
	public void setCrisisTeam(String team) {
		crisisTeam = team;
	}
	
	/**
	 * Utility Method to recompute the Priority of the Crisis based on its Events
	 */
	public void computeCrisisPriority() {
		int totalSeverity = 0;
		for(int i = 0; i < crisisEvents.length; i++) {
			//Iterate through each event
			totalSeverity += crisisEvents[i].getEventSeverity();
		}
		if(crisisEvents.length != 0) {
			crisisPriority = (int) totalSeverity / crisisEvents.length;
		}else {
			crisisPriority = 0;
		}
	}
	
	/**
	 * Utility Method to add and Event to the Crisis
	 * @param event Event to be added
	 */
	public void addEvent(Event event) {
		//Increase array of Events by one
		Event[] tempEvents = new Event[crisisEvents.length + 1];
		System.arraycopy(crisisEvents, 0, tempEvents, 0, crisisEvents.length);
		//Add new Member
		tempEvents[tempEvents.length -1] = event;
		crisisEvents = tempEvents;
		//Recompute Priority
		computeCrisisPriority();
	}
	
	/**
	 * Utility method to remove the last Event from the Crisis
	 */
	public void removeEvent() {
		//Remove last event by shrinking the array of Events
		if(crisisEvents.length > 0) {
			Event[] tempEvents = new Event[crisisEvents.length - 1];
			System.arraycopy(crisisEvents, 0, tempEvents, 0, crisisEvents.length-1);
			crisisEvents = tempEvents;
		}
	}
	
	/**
	 * Utility method to print the Crisis and all its Events
	 */
	public void printCrisis() {
		//Print team info
		System.out.println("-------------------------------");
		System.out.printf("%s\n\tID: %s\n\tTeam: \"%s\"\n", crisisName, crisisID, crisisTeam);
		System.out.println("\n- - - - - - Events - - - - - -");
		for(Event e : crisisEvents) {
			e.printEvent();
		}
		System.out.println("-------------------------------");
	}
}
