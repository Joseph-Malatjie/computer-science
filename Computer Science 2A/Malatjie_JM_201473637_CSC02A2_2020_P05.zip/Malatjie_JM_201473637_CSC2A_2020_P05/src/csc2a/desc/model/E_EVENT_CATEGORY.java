package csc2a.desc.model;
/**
 * Enumeration representing an Event's category
 * @author Mr Greaves
 * (Dystopian Emergency Services Council)
 * @version P03
 */
public enum E_EVENT_CATEGORY {
	DISASTER,
	HUMANITARIAN,
	WAR,
	FAMINE,
	PEACEKEEPING,
	TRAINING,
}