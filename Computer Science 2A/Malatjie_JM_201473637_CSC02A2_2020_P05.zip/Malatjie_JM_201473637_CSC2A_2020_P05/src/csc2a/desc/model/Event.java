package csc2a.desc.model;

/**
 * Class representing an Event
 * @author Mr Greaves
 * @author Joseph Malatjie
 * (Dystopian Emergency Services Council)
 * @version P03
 */

public abstract class Event implements iReportable
{
	/*
	 * Attributes
	 */
	protected String 	 eventID;
	protected String 			 eventName;
	protected E_EVENT_CATEGORY eventCategory;
	protected int 			 eventSeverity;
	protected boolean 		 eventResponded;
	protected int 			 eventVerification;
	
	/**
	 * Default Constructor
	 */
	public Event() 
	{
		eventID 		= "NoID";
		eventName 		= "NoName";
		eventCategory 	= E_EVENT_CATEGORY.TRAINING;
		eventSeverity 	= 0;
		eventResponded 	= false;
		eventVerification = 0;
	}
	
	/**
	 * Parameterized Constructor
	 * @param id
	 * @param name
	 * @param category
	 * @param severity
	 * @param responded
	 * @param verification
	 */
	Event(String name, String id, E_EVENT_CATEGORY category, int severity, boolean responded, int verification)
	{
		eventID 		= id;
		eventName 		= name;
		eventCategory 	= category;
		eventSeverity 	= severity;
		eventResponded 	= responded;
		eventVerification = verification;
	}
	
	/**
	 * Accessor for Event ID
	 * @return Event ID
	 */
	public String getEventID() {
		return eventID;
	}
	/**
	 * Accessor for Event Name
	 * @return Event Name
	 */
	public String getEventName() {
		return eventName;
	}
	/**
	 * Accessor for Event Category
	 * @return Event E_EVENT_CATEGORY
	 */
	public E_EVENT_CATEGORY getEventCategory() {
		return eventCategory;
	}
	/**
	 * Accessor for Event Severity
	 * @return Event Severity
	 */
	public int getEventSeverity() {
		return eventSeverity;
	}
	/**
	 * Accessor for Event Responded
	 * @return Event Responded
	 */
	public boolean getEventResponded() {
		return eventResponded;
	}
	
	/**
	 * accessor for event Verification
	 */
	public int getEventVerification()
	{
		return eventVerification;
	}
	
	/**
	 * Mutator for Event Name
	 * @param name Event Name
	 */
	public void setEventName(String name) {
		eventName = name;
	}
	/**
	 * Mutator for Event Category
	 * @param category Event E_EVENT_CATEGORY
	 */
	public void setEventCategory(E_EVENT_CATEGORY category) {
		eventCategory = category;
	}
	/**
	 * Mutator for Event Severity
	 * @param severity Event Severity
	 */
	public void setEventSeverity(int severity) {
		eventSeverity = severity;
	}
	/**
	 * Mutator for Event Responded
	 * @param responded Event Responded
	 */
	public void setEventResponded(boolean responded) {
		eventResponded = responded;
	}
	
	/**
	 * mutator for Event Verification
	 * @param verification
	 */
	public void setEventVrification(int verification)
	{
		eventVerification = verification;
	}
	
	/**
	 * Utility Method to Print the Event Info
	 */
	public void printEvent() {
		System.out.printf("\t>[%s] - %s[cat:%s@sev:%d] - Resp:%b\n", eventID, eventName, eventCategory.toString(), eventSeverity, eventResponded);
	}

	
	/**
	 * returns true if the verNumber is odd and returns false if the verNumber is even
	 * @param verNumber
	 * @return
	 */
	public static boolean verify(int verNumber)
	{
		if(verNumber % 2 == 1)
		{
			return true;
		}
		else
			return false;
	}
	
	/**
	 * helper method to display event severity
	 * @param intEventSeverity
	 * @return
	 */
	protected String strEventSeverity(int intEventSeverity)
	{
		String stringEventSeverity = " ";
		
		if(intEventSeverity == 1) {
			stringEventSeverity = "Low";
		}
		if(intEventSeverity > 1 & intEventSeverity < 4) {
			stringEventSeverity = "Moderate";
		}
		if(intEventSeverity > 3 & intEventSeverity < 7 ) {
			stringEventSeverity = "High";
		}
		if(intEventSeverity > 6) {
			stringEventSeverity = "Extreme";
		
		}
		return stringEventSeverity;
		
	}
	
	/*
	 * an abstract method overridden in the derived classes
	 */
	public abstract void issueReport(int X, int Y);
}	
