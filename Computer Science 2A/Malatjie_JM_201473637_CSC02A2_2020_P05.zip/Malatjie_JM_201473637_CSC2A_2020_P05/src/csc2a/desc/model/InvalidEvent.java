package csc2a.desc.model;

/**
 * 
 * @author Joseph Malatjie
 *
 */
public class InvalidEvent extends Event
{
	String streventSeverity = " ";
	
	/**
	 * parameterised constructor
	 * @param name
	 * @param id
	 * @param category
	 * @param severity
	 * @param responded
	 * @param verification
	 */
	public InvalidEvent(String name, String id, E_EVENT_CATEGORY category, int severity, boolean responded, int verification)
	{
		//setting up the values of the instance variables in the abstract class 
		super(name,id,category,severity,responded,verification);
	}


	@Override
	public void issueReport(int X, int Y) {
		
		//Saving the event severity to a string variable
		streventSeverity = strEventSeverity(eventSeverity);
		
		//displaying the event information
		System.out.printf("\n***Event***\nEvent Name: %s \nEventID: %s \nLocation: [%d,%d] \nResponded: %b \nEvent_Severity: %s \n"+"__>Invalid Event<__"+"\n ", eventName, eventID, X, Y, eventResponded,streventSeverity);
		
	}

}
