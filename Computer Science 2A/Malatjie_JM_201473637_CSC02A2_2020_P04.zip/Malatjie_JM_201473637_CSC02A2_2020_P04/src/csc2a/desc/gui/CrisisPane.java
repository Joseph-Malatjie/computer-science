package csc2a.desc.gui;

import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Accordion;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import java.io.File;
import csc2a.desc.file.CrisisFileHandler;
import csc2a.desc.model.Crisis;
import csc2a.desc.model.Event;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;

/**
 * 
 * @author Joseph Malatjie
 *
 */

public class CrisisPane extends StackPane{
	
	/**
	 * crisis instance
	 */
	private Crisis crisis = null;
	
	/**
	 * MenuBar instance
	 */
	private MenuBar menuBar = null;
	
	/**
	 * parameterless constructor
	 */
	public CrisisPane()
	{
		menuBar = new MenuBar();
		Menu menu = new Menu("File");
		menuBar.getMenus().add(menu);
		MenuItem menuItem = new MenuItem("Open");
		menu.getItems().add(menuItem);
		
		/**
		 * creating a file chooser to select the file to be displayed on the grid
		 */
		menuItem.setOnAction(new EventHandler<ActionEvent>()
		{
			
			@Override
			public void handle(ActionEvent event)
			{
				final FileChooser fc = new FileChooser();
				fc.setTitle("Choose Crisis Message");
				fc.setInitialDirectory(new File("./data"));
				File file = fc.showOpenDialog(null);
				
				if(file != null) {
					setCrisis(CrisisFileHandler.readCrisis(file));
				}
			}
			
		});
		
		//creating a VBox
		VBox vbox = new VBox();
		vbox.getChildren().add(menuBar);
		getChildren().add(vbox);
		
	}
	
	/**
	 * setting up crisis instance
	 * @param crisis
	 */
	public void setCrisis(Crisis crisis) 
	{
		this.crisis = crisis;
		createChildren();
	}
	
	/**
	 * creating an accordion 
	 */
	public void createChildren()
	{
		if(crisis != null)
		{
			Accordion accordion = new Accordion();
			
			TitledPane crisisTP = new TitledPane();
			crisisTP.setText("Crisis Information");
			GridPane grid = new GridPane();
			grid.setVgap(3);
			grid.setPadding(new Insets(7,7,7,7));
			grid.add(new Label("Name: "), 0, 0);
			grid.add(new TextField(crisis.getCrisisName()), 1, 0);
			grid.add(new Label("ID: "), 0, 1);
			grid.add(new TextField(crisis.getCrisisID()), 1, 1);
			grid.add(new Label("Crisis Team"), 0, 2);
			grid.add(new TextField(crisis.getCrisisTeam()), 1, 2);
			
			crisisTP.setContent(grid);
			
			TitledPane tpEvents = new TitledPane();
			tpEvents.setText("Events Information");
			VBox vbEvents = new VBox();
			ScrollPane spEvents = new ScrollPane();
			
			for(Event e: crisis.getEvents())
			{
				vbEvents.getChildren().add(createEventGrid(e));
			}
			
			spEvents.setContent(vbEvents);
			tpEvents.setContent(spEvents);
			
			accordion.getPanes().add(crisisTP);
			accordion.getPanes().add(tpEvents);
			
			getChildren().clear();
			getChildren().addAll(accordion);
		}
		
		
	}
	
	/**
	 * creating the grid for events
	 * @param event instance
	 * @return gridPane
	 */
	public GridPane createEventGrid(Event event)
	{
		//creating grid instance
		GridPane grid = new GridPane();
		
		//setting up the vertical gap of the grid
		grid.setVgap(5);
		
		//setting up the grid size
		grid.setPadding(new Insets(7,7,7,7));
		
		//creating a labelled text box for event
		grid.add(createLabeledTextBox("Name: ",event.getEventName()), 0, 0);
		
		/**
		 * creating the layout of the grid
		 */
		grid.add(new Label("ID: "), 0, 1);
		grid.add(new TextField(event.getEventID()), 1, 1);
		
		grid.add(new Label("Category"), 0, 2);
		grid.add(new TextField(event.getEventID().toString()), 1, 2);
		
		grid.add(new Label("Responded: "), 0, 3);
		grid.add(new TextField(Boolean.toString(event.getEventResponded())), 1, 3);
		
		grid.add(new Label("Event Severity: "), 0,4);
		
		//creating a progress bar to be able to scroll through the grid
		ProgressBar proBar = new ProgressBar();
		proBar.setProgress(event.getEventSeverity());
		grid.add(proBar, 1, 4);
		
		return grid;
	}
	
	/*
	 * Helper method 
	 */
	public GridPane createLabeledTextBox(String label, String text )
	{
		GridPane grid = new GridPane();
		grid.add(new Label(label), 0, 1);
		grid.add(new TextField(text), 1, 1);
		return grid;
	}
}
