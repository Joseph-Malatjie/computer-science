import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import csc2a.desc.javafx.CrisisPane;

/**
 * 
 * @author Joseph Malatjie
 *
 */
public class Main extends Application {
	
	//an instance of CrisisPane
	private CrisisPane pane = null; 

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
		launch(args);

	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		
		//the title of the Stage
		primaryStage.setTitle("Crisis and Events display");
		
		//creating a crisisPane object
		 pane = new CrisisPane();
		
		 //creating a scene
		 Scene scene = new Scene(pane);
		 
		 //setting up the size of the Stage
		 primaryStage.setWidth(500);
		 primaryStage.setHeight(600);
		 
		//setting up the scenes
		 primaryStage.setScene(scene);
		 
		 //Displaying the information
		 primaryStage.show();
		
	}

}
