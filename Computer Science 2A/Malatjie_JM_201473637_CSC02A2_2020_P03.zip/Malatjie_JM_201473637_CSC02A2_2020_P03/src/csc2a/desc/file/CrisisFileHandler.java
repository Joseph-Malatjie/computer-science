package csc2a.desc.file;
import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.StringTokenizer;

import csc2a.desc.Crisis;
import csc2a.desc.Event;
import csc2a.desc.E_EVENT_CATEGORY;

/**
 * 
 * @author Joseph Malatjie
 *
 */

public class CrisisFileHandler {

	
	/**
	 * Regex that will match Crisis header pattern
	 * 
	 * ([A-Z0-9]+)\t([A-Za-z]+\s)+(\*([(A-Za-z)]+\s)+[A-Za-z]+\*)
	 */
	private static final Pattern crisisHeaderPattern = Pattern.compile("([A-Z0-9]+)\\t([A-Za-z]+\\s)+(\\*([(A-Za-z)]+\\s)+[A-Za-z]+\\*)");
	
	/*
	 * Regex that will match Event information pattern
	 * ([A-Z0-9]+)\t([A-Za-z]+\s)+((\[([A-Z,"@",0-9]+)\])\t[a-z]+)
	 */
	
	private static final Pattern eventPattern = Pattern.compile("([A-Z0-9]+)\\t([A-Za-z]+\\s)+((\\[([A-Z,\"@\",0-9]+)\\])\\t[a-z]+)");
	
	public static Crisis readCrisis(File Filename)
	{
		/**
		 * return reference
		 */
		Crisis crisis = null;
		
		//verifying that the file does exist
		if(!Filename.exists())
		{
			System.err.println("File does not exist");
			return crisis;
		}

		Scanner input = null;
		try {
			
			//opening the file
			input = new Scanner(Filename);
			
			//verifying that the file is not empty
			if(!input.hasNext())
			{
				System.err.println("File is Empty");
				return crisis;
			}
			
			/*
			 * Storing crisis header in the variable to be verified
			 */
			String CrisisHeader = input.nextLine();
			//System.out.println(CrisisHeader);
			
			//validating with Regular Expression
			Matcher crisisHeaderMatcher = crisisHeaderPattern.matcher(CrisisHeader);
			
			//if the contents don't match, return null 
			if(!crisisHeaderMatcher.matches())
			{
				System.err.println("Crisis header does not match: " + CrisisHeader);
				return crisis;
			}
			
			StringTokenizer crisisHeaderTokenizer = new StringTokenizer(CrisisHeader,"\t");
			String crisisID = crisisHeaderTokenizer.nextToken();
			String crisisName = crisisHeaderTokenizer.nextToken();
			String crisisTeam = crisisHeaderTokenizer.nextToken();
			
			crisisTeam = crisisTeam.substring(1,crisisTeam.length()-1);
		
			
			System.out.printf("--------Crisis Header---------\nCR_ID: %s\nCR_Name: %s\nCR_Team: %s\n", crisisID,crisisName,crisisTeam);
			
			
			crisis = new Crisis(crisisID,crisisName,crisisTeam);
			
			while(input.hasNext())
			{
				String eventLine = input.nextLine();
				Matcher eventsMatcher = eventPattern.matcher(eventLine);
				
				if(!eventsMatcher.matches())
				{
					System.out.println("Crisis eventLine does not match: " + eventLine);
				}
				else
				{
					Event events = eventFromString(eventLine);
					crisis.addEvent(events);
				}
			}
			
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();			
		}
		finally
		{
			if(input != null) 
				input.close();
		}
		return crisis;
	}
	
	private static Event eventFromString(String eventString)
	{
		//StringTokenizer to separate the data of events
		StringTokenizer eventTokens = new StringTokenizer(eventString,"\t");
		String eventID = eventTokens.nextToken();
		String eventName = eventTokens.nextToken();
		String eventAtributes = eventTokens.nextToken();
		boolean eventResponded = Boolean.parseBoolean(eventTokens.nextToken());
		
		//removing the square brackets
		eventAtributes = eventAtributes.substring(1,eventAtributes.length()-1);
		
		StringTokenizer eventAtributesTokens = new StringTokenizer(eventAtributes,"@");
		E_EVENT_CATEGORY eventCategory = E_EVENT_CATEGORY.valueOf(eventAtributesTokens.nextToken());
		int eventSeverity = Integer.parseInt(eventAtributesTokens.nextToken());
		
		//printing the events information
		System.out.printf("------------Events-----------\nEV_ID: %s\nEV_Name: %s\nEV_CATEGORY: %s\nEV_SEVERITY: %s\nEV_RESPONDED: %s\n",eventID,eventName,eventCategory,eventSeverity,eventResponded);
		
		//creating an instance of the class Event
		Event tempEvent = new Event(eventID,eventName,eventCategory,eventSeverity,eventResponded); 
		return tempEvent;
	}
}




