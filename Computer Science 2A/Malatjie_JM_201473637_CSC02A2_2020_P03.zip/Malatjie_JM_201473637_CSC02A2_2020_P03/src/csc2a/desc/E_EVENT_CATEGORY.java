package csc2a.desc;
/**
 * 
 * @author JM Malatjie
 *
 */
public enum E_EVENT_CATEGORY {

	DISASTER,HUMANITARIAN,WAR,FAMINE,PEACEKEEPING,TRAINING
}
