package csc2a.desc;
/**
 * 
 * @author Mr Greaves
 * (Dystopian Emergency Services Council)
 */
public class Event {
		
	/*
	 * Attributes
	 */
	private final String 		eventID;
	private String 				eventName;
	private E_EVENT_CATEGORY	eventCategory;
	private int 				eventSeverity;
	private boolean 			eventResponded;
	/**
	 * Default Constructor
	 */
	public Event() {
		eventID 		= "NoID";
		eventName 		= "NoName";
		eventCategory 	= E_EVENT_CATEGORY.TRAINING;
		eventSeverity 	= 1;
		eventResponded 	= false;
	}
	
	/**
	 * Parameterized Constructor
	 * @param id Unique Event ID
	 * @param name Event Name
	 * @param category Event Category
	 * @param severity Event Severity (1-10)
	 * @param responded Whether the event has been responded to (true/false)
	 */
	public Event(String id, String name, E_EVENT_CATEGORY category, int severity, boolean responded) {
		eventID 		= id;
		eventName 		= name;
		eventCategory 	= category;
		eventSeverity 	= severity;
		eventResponded 	= responded;
	}
	
	/**
	 * Accessor for Event ID
	 * @return Event ID
	 */
	public String getEventID() {
		return eventID;
	}
	/**
	 * Accessor for Event Name
	 * @return Event Name
	 */
	public String getEventName() {
		return eventName;
	}
	/**
	 * Accessor for Event Category
	 * @return Event Category
	 */
	public E_EVENT_CATEGORY getEventCategory() {
		return eventCategory;
	}
	/**
	 * Accessor for Event Severity
	 * @return Event Severity
	 */
	public int getEventSeverity() {
		return eventSeverity;
	}
	/**
	 * Accessor for Event Responded
	 * @return Event Responded
	 */
	public boolean getEventResponded() {
		return eventResponded;
	}
	
	/**
	 * Mutator for Event Name
	 * @param name Event Name
	 */
	public void setEventName(String name) {
		eventName = name;
	}
	/**
	 * Mutator for Event Category
	 * @param category Event Category
	 */
	public void setEventCategory(E_EVENT_CATEGORY category) {
		eventCategory = category;
	}
	/**
	 * Mutator for Event Severity
	 * @param severity Event Severity
	 */
	public void setEventSeverity(int severity) {
		eventSeverity = severity;
	}
	/**
	 * Mutator for Event Responded
	 * @param responded Event Responded
	 */
	public void setEventResponded(boolean responded) {
		eventResponded = responded;
	}
	
	/**
	 * Utility Method to Print the Event Info
	 */
	public void printEvent() {
		System.out.printf("\t>[%s] - %s[cat:%s@sev:%d] - Resp:%b\n", eventID, eventName, eventCategory, eventSeverity, eventResponded);
	}
}	
