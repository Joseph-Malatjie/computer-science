import csc2a.desc.Crisis;
import csc2a.desc.E_EVENT_CATEGORY;
import java.io.File;
import csc2a.desc.Event;
import csc2a.desc.file.CrisisFileHandler;
/**
 * 
 * @author JM Malatjie
 * (Dystopian Emergency Services Council)
 */
public class Main {
	/**
	 * Entry Point for the program
	 * @param args Arguments passed to program
	 */
	public static void main(String[] args) {
	/*	//Create first Crisis
		Crisis cOne = new Crisis("C26A45", "Storm Dennis", "Rescue Team Alpha");
		//Add Events to Crisis
		cOne.addEvent(new Event("E25H67", "Midlands Flood", E_EVENT_CATEGORY.PEACEKEEPING, 8, false));
		cOne.addEvent(new Event("E26A98", "Property Damage", E_EVENT_CATEGORY.HUMANITARIAN, 5, true));
		
		//Create second Crisis
		Crisis cTwo = new Crisis("D46B21", "Australian Fires", "Support Team Delta");
		//Add Events to Crisis
		cTwo.addEvent(new Event("E12J32", "People Displaced", E_EVENT_CATEGORY.HUMANITARIAN, 4, true));
		cTwo.addEvent(new Event("E13K67", "Fire", E_EVENT_CATEGORY.DISASTER, 10, true));
		
		//Print
		cOne.printCrisis();
		cTwo.printCrisis(); */
		
		File CrisisFile = new File("docs/C04H76 - Clean.txt");
		Crisis crisisFromFile = CrisisFileHandler.readCrisis(CrisisFile);
		crisisFromFile.printCrisis();
	}
}