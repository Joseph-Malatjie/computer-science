package csc2b.Server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class httpServer 
{
	private ServerSocket serverS = null;
	public static boolean inprogress = false;
	
	public httpServer(int Port)
	{
		try 
		{
			serverS = new ServerSocket(Port);
			System.out.println("waiting for a connection");
			inprogress = true;
		} 
		catch (IOException e) 
		{	
			System.err.println("server connection error: Connection failed!!");;
		}
	}
	
	public void runServer()
	{
		while(inprogress)
		{
			try 
			{
				Socket connection = serverS.accept();
				ClientHandler ch = new ClientHandler(connection);
				
				Thread thread = new Thread(ch);
				thread.start();
			} 
			catch (IOException e) {
	
				System.err.println("Connection failed");
			}
			
		}
	}
}
