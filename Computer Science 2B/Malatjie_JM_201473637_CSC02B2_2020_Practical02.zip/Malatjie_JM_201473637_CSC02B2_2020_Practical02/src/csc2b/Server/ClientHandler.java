package csc2b.Server;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.StringTokenizer;

public class ClientHandler implements Runnable
{

	Socket connection;
	
	public ClientHandler(Socket clientConnection)
	{
		connection = clientConnection;
	}
	
	@Override
	public void run()
	{
		BufferedReader input = null;
		DataOutputStream output = null;
		String fileName;
		File file;
		
		try 
		{
			input = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			output = new DataOutputStream(new BufferedOutputStream(connection.getOutputStream()));
			
			String request = input.readLine();
			System.out.println(request);
			
			StringTokenizer st = new StringTokenizer(request);
			String requestType = st.nextToken();
			fileName = st.nextToken().substring(1);
			file = new File(fileName);
			

			
			if(requestType.equals("GET"))
			{
				//HTTP/1.1 200 OK \r\n
				
				output.writeBytes("HTTP/1.1 200 OK \r\n");
				output.writeBytes("Connection: close \r\n");
				output.writeBytes("Content-Type: text/html \r\n");
				output.writeBytes("Content-Length: " + file.length()+ "\r\n");
				output.writeBytes("\r\n");
	
				BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));

				
				byte[] byteArray = new byte[1024];
				
				int b = 0;
				
				while((b = bis.read(byteArray)) > 0)
				{
					output.write(byteArray,0,b);
				}
				bis.close();
				output.writeBytes("/r/n");
				output.flush();
				
			}
			else
			{
				
				fileName = "501.html";
				file = new File(fileName);
				output.writeBytes("HTTP/1.1 501 an error occured \r\n");
				output.writeBytes("Connection: close \r\n");
				output.writeBytes("Content-Type: text/html \r\n");
				output.writeBytes("Content-Length: " + file.length()+ "\r\n");
				output.writeBytes("\r\n");

				BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));

				byte[] byteArray = new byte[1024];
				
				int b = 0;
				
				while((b = bis.read(byteArray)) > 0)
				{
					output.write(byteArray,0,b);
				}
				bis.close();
				output.writeBytes("/r/n");
				output.flush();
			}
			
			
			
		}
		catch(FileNotFoundException e)
		{
			filenotfound();
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				input.close();
				output.close();
				//when the socket closes, the sever should stop running
				httpServer.inprogress = false;
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
		
	}
	
	private void filenotfound()
	{
		DataOutputStream output = null;
		try
		{
			
			output = new DataOutputStream(new BufferedOutputStream(connection.getOutputStream()));
			
			
			String fileName = "DOC/404.html";
			File file = new File(fileName);
			output.writeBytes("HTTP/1.1 200 OK \r\n");
			output.writeBytes("Connection: close \r\n");
			output.writeBytes("Content-Type: text/html \r\n");
			output.writeBytes("Content-Length: " + file.length()+ "\r\n");
			output.writeBytes("\r\n");
			
			BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
				
			byte[] byteArray = new byte[1024];
			
			int b = 0;
			
			while((b = bis.read(byteArray)) > 0)
			{
				output.write(byteArray,0,b);
			}
			bis.close();
			output.writeBytes("/r/n");
			output.flush();
		}
		catch(Exception e) 
		{
			System.err.println("Error: " + e.getMessage());
		}
		
		  finally 
		  { 
			  try 
			  {
				  output.close(); 
				  httpServer.inprogress = false;
			  } 
			  catch (IOException e) 
			  {
				  e.printStackTrace(); 
			  } 
		  }
		 
	}

}
