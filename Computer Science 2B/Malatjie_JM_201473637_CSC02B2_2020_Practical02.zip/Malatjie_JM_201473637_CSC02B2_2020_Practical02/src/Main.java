import csc2b.Server.httpServer;

public class Main {

	public static void main(String[] args) 
	{
		httpServer server = new httpServer(1234);
		server.runServer();
	}

}
