package csc2b.Client;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class ClientInterface extends GridPane
{
	//JavaFX elements
	private Button connect;
	private Button show;
	private Button landing;
	private Button Takeoff;
	private Label lblId;
	private TextField txtID;
	private TextArea txtShow;
	
	//Streams and socket
	private BufferedReader input = null;
	private PrintWriter output = null;
	private DataInputStream dis = null;
	private DataOutputStream dos = null;
	private OutputStream out = null;
	private InputStream in = null;
	private Socket socket = null;
	
	/**
	 * 
	 */
	public ClientInterface()
	{
		Initialise();
		
		connect.setOnAction((event) ->
		{
			try
			{
				socket = new Socket("Localhost",2844);
				in = socket.getInputStream();
				out = socket.getOutputStream();
				input = new BufferedReader(new InputStreamReader(in));
				output = new PrintWriter(out);
				dis = new DataInputStream(in);
				dos = new DataOutputStream(out);
				
				txtShow.appendText("Connected to Server\n\n");
				
			}
			catch(IOException e)
			{
				e.printStackTrace();			
			}

		});
		
		show.setOnAction((event) -> 
		{
			Scanner in = null;
			
			output.println("SHOW");
			output.flush();
			
			try
			{
				String response = input.readLine();
				int filesize = Integer.parseInt(response);
				
				File file = new File("data/client/files.txt");
				FileOutputStream fos = new FileOutputStream(file);

				byte[] b = new byte[1024];
				int n = 0;
				int totalbytes = 0;
				
				while(totalbytes != filesize)
				{
					n = dis.read(b,0,b.length);
					fos.write(b,0,n);
					fos.flush();
					totalbytes += 1;
				}
				
				File files = new File("data/client/files.txt");
				in = new Scanner(files);
				while(in.hasNext())
				{
					String fileinfo = in.nextLine(); 
					txtShow.appendText(fileinfo + "\n");
				}
				
				//closing the filestream
				fos.close();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
			finally
			{
				try 
				{
					dis.close();
					input.close();
					output.close();
				} 
				catch (IOException e) 
				{
					e.printStackTrace();
				}
			}
		});
		
		landing.setOnAction((event) ->
		{
			String ID = txtID.getText();
			
			output.println("LANDING <"+ID+">");
			output.flush();
			
			output.println(ID);
			output.flush();
			
			try
			{
				String response = input.readLine();
				int filesize = Integer.parseInt(response);
				
				String filename = input.readLine();
						
				File file = new File("data/client/"+filename+"");
				FileOutputStream fos = new FileOutputStream(file);
				byte[] buffer = new byte[1024];
				int n = 0;
				int totalbytes = 0;
				
				while(totalbytes != filesize)
				{
					n = dis.read(buffer,0,buffer.length);
					fos.write(buffer,0,n);
					fos.flush();
					totalbytes += 1;
				}
				fos.close();			
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
			finally
			{
				try 
				{
					dis.close();
					input.close();
					output.close();
				} 
				catch (IOException e) 
				{
					e.printStackTrace();
				}
			}
			
			
		});
		
		Takeoff.setOnAction((event) ->
		{
			
		});
		
	}
	
	private void Initialise()
	{
		setVgap(10);
		
		Label header = new Label("CLIENT APPLICATION");
		header.setFont(Font.font("Arial",FontWeight.BOLD,26));
		add(header,0,0,1,1);
		
		txtShow = new TextArea();
		txtShow.setPrefSize(500.00,300.00 );;
		add(txtShow,0,2,1,1);
		
		connect = new Button("Connect");
		connect.setPrefSize(100, 30);
		add(connect,0,3,1,1);
		
		show = new Button("Show Files");
		show.setPrefSize(100, 30);
		add(show,0,4,1,1);
		
		landing = new Button("Return file");
		landing.setPrefSize(100, 30);
		add(landing,0,7,1,1);
		
		Takeoff = new Button("Send File");
		Takeoff.setPrefSize(100, 30);
		add(Takeoff,0,8,1,1);
		
		lblId = new Label("File ID");
		add(lblId,0,5,1,1);
		
		txtID = new TextField();
		txtID.setMaxWidth(100);
		add(txtID,0,6,1,1);
		
	}
	
}
