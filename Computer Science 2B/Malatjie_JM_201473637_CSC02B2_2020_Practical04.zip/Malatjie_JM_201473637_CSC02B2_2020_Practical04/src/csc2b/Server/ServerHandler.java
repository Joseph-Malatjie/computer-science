package csc2b.Server;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class ServerHandler implements Runnable
{
	private Socket connection;
	private BufferedReader input = null;
	private PrintWriter output = null;
	private DataOutputStream dos = null;
	private DataInputStream dis = null;
	private OutputStream os = null;
	private InputStream is = null;
	
	private boolean running;
	
	public ServerHandler(Socket connections)
	{
		this.connection = connections;
		
		try 
		{
			is = connection.getInputStream();
			os = connection.getOutputStream();
			
			dis = new DataInputStream(is);
			dos = new DataOutputStream(os);
			
			input = new BufferedReader(new InputStreamReader(is));
			output = new PrintWriter(os);
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	public void run() 
	{	
		try
		{
			running = true;
			
			while(running)
			{
				String command = input.readLine();
				Scanner in = null;
				FileInputStream fis = null;
				
				if(command.equals("SHOW"))
				{
					File textF = new File("data/server/PdfList.txt");
					
					if(textF.exists())
					{	
						output.println(textF.length());
						output.flush();
												
						fis = new FileInputStream(textF);
						byte[] buffer = new byte[1024];
						int n = 0;
						
						while((n = fis.read(buffer)) > 0)
						{
							dos.write(buffer,0,n);
							dos.flush();
						}	
						fis.close();	
					}
				}
				
				String ID = input.readLine();
				if(command.equals("LANDING <"+ID+">"))
				{
					String filename = "";
					File textFile = new File("data/server/PdfList.txt");
					in = new Scanner(textFile);
					
					while(in.hasNext())
					{
						String tempfilename = in.nextLine();
						System.out.println(tempfilename);
						if(tempfilename.startsWith(ID))
						{
							filename = tempfilename.substring(2);
						}
					}
				
					File file = new File("data/server/"+filename+"");
					
					if(file.exists())
					{
						output.println(file.length());
						output.flush();
						
						output.println(filename);
						output.flush();
						
						FileInputStream fs = new FileInputStream(file);
						byte[] buffer = new byte[1024];
						int n = 0;
						
						while((n = fs.read(buffer)) > 0)
						{
							dos.write(buffer,0,n);
							dos.flush();
						}
						fs.close();	
						
					}
				}
			}
			
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				output.close();
				input.close();
				dos.close();
				connection.close();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
	}

}
