package csc2b.Server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	
	private ServerSocket server;
	private boolean running;
	
	public Server(int port)
	{
		try 
		{
			server = new ServerSocket(port);
			System.out.println("Server running on port " + port);
			running = true;
			
			while(running)
			{
				Socket connection = server.accept();
				Thread thread = new Thread(new ServerHandler(connection));
				thread.start();
				
				if(connection.isClosed())
				{
					running = false;
				}
			}
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				server.close();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		
		Server server = new Server(2844);
		
	}

}
