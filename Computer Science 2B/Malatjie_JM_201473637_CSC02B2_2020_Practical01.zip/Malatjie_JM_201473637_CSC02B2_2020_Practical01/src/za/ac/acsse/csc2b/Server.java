package za.ac.acsse.csc2b;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;
import java.util.Scanner;

public class Server {

	public static void main(String[] args) {
		
		ServerSocket serverS = null;
		Socket connection = null;
		PrintWriter output = null;
		Scanner input = null;
		try 
		{
			//binding the server to a socket
			serverS = new ServerSocket(8888);
			
			System.out.println("Waiting for a connection :)");
			connection = serverS.accept();
			
			//Declaring the input and output streams 
			output = new PrintWriter(connection.getOutputStream(),true);
			input = new Scanner(new InputStreamReader(connection.getInputStream()));
		
			output.println("HELLO - You may ask me 4 questions");
			
			String text = input.nextLine();
			text = "";
			
			//to help terminate the program
			boolean inprogress = true;
			
			while(inprogress)
			{
				int index = 0;
				
				output.println("ASK me a Question or DONE");
				
				//Client can only ask 4 questions
				for(int i = 0; i<4; i++)
				{
					text = input.nextLine();

					//if the client's question contains the words "covid19" or "virus"
					if((index = text.indexOf("virus")) != -1 || (index = text.indexOf("covid19")) != -1)
					{
						output.println("0"+(i+1)+" Please see sacoronavirus.co.za");
					}
					else if(text.indexOf("Are") == 4) //if the client's question starts with an "Are"
					{
						Random rand = new Random();
						index = rand.nextInt(10);
						
						if(index % 2 == 0)
						{
							output.println("0"+(i+1)+" Yes");
						}
						else if(index % 2 == 4) 
						{
							output.println("0"+(i+1)+" No");
						}
						else
						{
							output.println("0"+(i+1)+" Maybe");
						}
			
					}
					else if(text.indexOf("Why") == 4) //if the client's question starts with a "why"
					{
						output.println("0"+(i+1)+" Because the boss says so - see Ulink");
					}
					else if(text.equals("DONE"))
					{
						output.println("0"+(i+1)+" OK BYE - "+i+" question(s) answered");
						i = 5;
						inprogress = false;
					}
					else 
					{
						Random rand = new Random();
						index = rand.nextInt(10);
						
						if(index % 2 == 0)
						{
							output.println("0"+(i+1)+" Oh ok!");
						}
						else if(index % 2 == 3)
						{
							output.println("0"+(i+1)+" Meh");
						}
						else 
						{
							output.println("0"+(i+1)+" Escusez-moi?");
						}
					}
					
					//terminating the program when the client has asked 4 questions
					if(i==3)
					{
						inprogress = false;
						output.println("HAPPY TO HAVE HELPED - 4 Questions answered");
					}
				}
			}
			
			
		} 
		catch (IOException e) 
		{
			System.err.println("Could not bind to port");
		}
		finally
		{
			try
			{
				serverS.close();
				connection.close();
				input.close();
				output.close();
			} 
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}

	}

}
