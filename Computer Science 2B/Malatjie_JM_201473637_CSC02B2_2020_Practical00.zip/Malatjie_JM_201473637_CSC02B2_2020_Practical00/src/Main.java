import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class Main {

	public static void main(String[] args) {
		
		try {
			
			//printing out the ip address
			System.out.println("The computer IP Address is: " + InetAddress.getLocalHost().getHostAddress());
			System.out.println("Open port numbers include: ");
			
			//Scanning for open ports
			for(int i = 1; i < 65536; i++)
			{
				scan(i);
			}
		}
		catch (UnknownHostException e) 
		{
			e.printStackTrace();
			
		} 
		
	}
	
	public static void scan(int num) 
	 {
		Socket client = null;
		 try {
			 //establishing a connection to a port
			client = new Socket("localhost",num);
			System.out.println(num);
		 }
		 catch (IOException e) 
			{	
				System.err.println("Connection to port failed");
			}
			finally
			{
				if(client != null)
				{
					try 
					{	
						client.close();	
					} 
					catch (IOException e) 
					{	
						e.printStackTrace();
					}
				}
			}
			
	 }

}
