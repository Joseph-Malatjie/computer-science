package csc2b.Client;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.FileChooser;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Base64;


public class SceneHandler {

    //Streams and socket
    private BufferedReader input = null;
    private OutputStream out = null;
    private InputStream in = null;
    private Socket socket = null;
    private File file = null;
    private DataOutputStream dos = null;
    private BufferedOutputStream bos = null;
    String grayScaleAPI = "/api/GrayScale";

    @FXML
    private ImageView imgViewer;

    @FXML
    private ImageView cannyImageView;


    @FXML
    void startClick(ActionEvent event) {
        try
        {
            //instantiating the streams and the socket
            socket = new Socket("Localhost",5000);
            in = socket.getInputStream();
            out = socket.getOutputStream();
            input = new BufferedReader(new InputStreamReader(in));
            bos = new BufferedOutputStream(out);
            dos = new DataOutputStream(bos);
            System.out.println("Connected to server");

            Parent root = FXMLLoader.load(getClass().getResource("MainScene.fxml"));
            Stage mainStage = (Stage)((Node)event.getSource()).getScene().getWindow();
            mainStage.setScene(new Scene(root, 873.0, 885.0));
            mainStage.show();
        }
        catch (UnknownHostException uh)
        {
            uh.printStackTrace();
        }
        catch (IOException io)
        {
            io.printStackTrace();
        }
    }

    @FXML
    void openClick(ActionEvent event) {

        //instantiating the streams and the socket
        try {
            socket = new Socket("Localhost",5000);
            in = socket.getInputStream();
            out = socket.getOutputStream();
            input = new BufferedReader(new InputStreamReader(in));
            bos = new BufferedOutputStream(out);
            dos = new DataOutputStream(bos);
        } catch (IOException e) {
            e.printStackTrace();
        }

        final FileChooser fc = new FileChooser();
        fc.setTitle("Choose Image File");
        fc.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
                new FileChooser.ExtensionFilter("Audio Files", "*.wav", "*.mp3", "*.aac"),
                new FileChooser.ExtensionFilter("All Files", "*.*"));
        fc.setInitialDirectory(new File("./data"));
        file = fc.showOpenDialog(null);

        String[] list = new String[2];


        setGrayscale(file);

    }

    private void setGrayscale(File file)
    {
        if(file != null)
        {
            String encodedFile = null;
            try
            {
                    String fileName = file.getName();
                    File imgFile = new File("data",fileName);
                    FileInputStream fileInputStreamReader = new FileInputStream(imgFile);
                    int length = (int)file.length();
                    byte[] bytes = new byte[length];
                    fileInputStreamReader.read(bytes);
                    encodedFile = new String(Base64.getEncoder().encodeToString(bytes));
                    byte[] bytesToSend = encodedFile.getBytes();
                    System.out.println("Encoded string: " + encodedFile);
                    dos.write(("POST " + grayScaleAPI +" HTTP/1.1\r\n").getBytes());
                    dos.write(("Content-Type: " +"application/text\r\n").getBytes());
                    dos.write(("Content-Length: "+encodedFile.length()+"\r\n").getBytes());
                    dos.write(("\r\n").getBytes());
                    dos.write(bytesToSend);
                    dos.write(("\r\n").getBytes());
                    dos.flush();
                    String response = "";
                    String line = "";

                    while(!(line = input.readLine()).equals(""))
                    {
                        response += line+"\n";
                    }
                    String imgData = "";

                    while((line = input.readLine()) != null)
                    {
                        imgData += line;
                    }

                    String base64str = imgData.substring(imgData.indexOf('\'')+1,imgData.lastIndexOf('}')-1);
                    byte[] decodedString = Base64.getDecoder().decode(base64str);
                    Image Img = new Image(new ByteArrayInputStream(decodedString));
                    imgViewer.setImage(Img);




            } catch (FileNotFoundException e)
            {
                e.printStackTrace();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }

}

