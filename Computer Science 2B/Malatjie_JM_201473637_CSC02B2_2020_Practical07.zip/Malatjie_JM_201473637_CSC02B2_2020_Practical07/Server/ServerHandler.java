package Server;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
import java.util.StringTokenizer;

import javax.imageio.ImageIO;

public class ServerHandler implements Runnable 
{
	private Socket connection;
	private BufferedReader input = null;
	private PrintWriter output = null;
	private OutputStream os = null;
	private InputStream is = null;
	
	public ServerHandler(Socket connection1)
	{
		connection = connection1;
		
		try 
		{
			//instantiating the streams
			is = connection.getInputStream();
			os = connection.getOutputStream();
			input = new BufferedReader(new InputStreamReader(is));
			output = new PrintWriter(os);	
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}

	@Override
	public void run() 
	{
		boolean running = true;
		
		while(running)
		{
			String message = "";
			try 
			{
				//reading the command from the client
				message = input.readLine();
				StringTokenizer token = new StringTokenizer(message);
				String command = token.nextToken();
				
				//evaluating the command
				switch(command)
				{
				case "DATA":
				{
					//sending feedback to the client
					output.println(txtFileList());
					output.flush();
				}
				break;
				
				case "IMGRET":
				{
					int id = Integer.parseInt(token.nextToken()); 
					
					//getting the image from the the server folder
					BufferedImage image = getImage(id);
					
					//sending the image to the client
					ImageIO.write(image,"JPG", os);
				}
				break;
				
				case "IMGSEND":
				{
					int id = Integer.parseInt(token.nextToken());
					String imageName = token.nextToken();
					
					//Receiving an image from the client
					BufferedImage bImage = ImageIO.read(is);
					
					//saving the image using the helper method
					saveImage(id,imageName,bImage);
					running = false;
				}
				break;
				
				}
				
			}
			catch (IOException e) 
			{
				e.printStackTrace();
			}
			
		}
	}
	
	private BufferedImage getImage(int id)
	{
		BufferedImage image = null;
		String imgName = "";
		Scanner scanner = null;
		
		try
		{
			File file = new File("./data/server/fileList.txt");
			
			scanner	= new Scanner(file);
			
			while(scanner.hasNextLine())
			{
				String line = scanner.nextLine();
				StringTokenizer token = new StringTokenizer(line);
				int ID = Integer.parseInt(token.nextToken());
				String tempImgName = token.nextToken();
				
				if(ID == id)
				{
					imgName = tempImgName;
				}
			}
			
			image = ImageIO.read(new File("data/server/",imgName));
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (IOException e) 
		{	
			e.printStackTrace();
		}
		
		return image;
	}
	
	private String txtFileList()
	{
		String fileContents = "";
		
		File textF = new File("./data/server/fileList.txt");
		
		try 
		{
			Scanner sc = new Scanner(textF);
			
			while(sc.hasNextLine())
			{
				String temp = sc.nextLine();
				fileContents += temp+":";	 
			}
			sc.close();
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		
		return fileContents;
	}
	
	private void saveImage(int id, String imgName, BufferedImage bImage)
	{
		try 
		{
			//writing the id and image name to the fileList text file
			PrintWriter printW = new PrintWriter(new BufferedWriter(new FileWriter("./data/server/fileList.txt",true)));
			printW.println("\n"+id +" "+ imgName);
			printW.close();
			System.out.println("Append to file");
			//saving an image to the server  folder 
			ImageIO.write(bImage, "JPG", new File("./data/server/",imgName));
			
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
}
