package accse.csc2b;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
{
    private BufferedReader input = null;
    private PrintWriter output = null;
    private OutputStream out = null;
    private InputStream in = null;
    private Socket socket = null;
    private String[] fileList;
    private int imageID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView text = (TextView) findViewById(R.id.txtMessage);
        Button connect = (Button) findViewById(R.id.btnConnect);
        Button list = (Button) findViewById(R.id.btnList);
        Button download = (Button) findViewById(R.id.btnDownload);
        ImageView image = (ImageView) findViewById(R.id.imgView);
        final ListView lView = (ListView) findViewById(R.id.lstList);

        connect.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                new connectServer().execute();
                text.setText("Connected to server");
            }
        });

        list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                int SDK_INT = android.os.Build.VERSION.SDK_INT;
                if (SDK_INT > 8)
                {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    output.println("DATA");
                    output.flush();
                }


                String response;
                try
                {
                    response = input.readLine();
                    ArrayList<String> listV = new ArrayList<String>();
                    //splitting the strings
                    fileList = response.split(":");

                    for(int i = 0; i < fileList.length; i++)
                    {
                        listV.add(fileList[i]);
                    }

                    lView.setAdapter(returnL(listV));
                    lView.setOnItemClickListener(new AdapterView.OnItemClickListener()
                    {

                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            imageID = position;
                        }
                    });
                }
                catch (IOException e1)
                {
                    e1.printStackTrace();
                }
            }
        });

        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int SDK_INT = android.os.Build.VERSION.SDK_INT;
                if (SDK_INT > 8)
                {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    output.println("IMGRET "+imageID);
                    output.flush();
                }

            }
        });

    }

    private class connectServer extends AsyncTask<Void,Void,Void>
    {

        @Override
        protected Void doInBackground(Void... voids)
        {
            try
            {
                socket = new Socket("10.0.2.2",7455);
                in = socket.getInputStream();
                out = socket.getOutputStream();
                output = new PrintWriter(out);
                input = new BufferedReader(new InputStreamReader(in));

            } catch (IOException e)
            {
                e.printStackTrace();
            }
            return null;
        }
    }

    private ArrayAdapter returnL(ArrayList<String> list) {

        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,list);
        return adapter;
    }

}