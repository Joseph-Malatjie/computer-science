package csc2b.Client;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.imageio.ImageIO;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;

public class ClientInterface extends GridPane
{
	//JavaFX elements
	private Button connect;
	private Button show;
	private Button getImage;
	private Button sendImage;
	private TextArea txtResponse;
	private Label lblResponse;
	private TextField txtID;
	private TextArea txtArea;
		
	//Streams and socket
	private BufferedReader input = null;
	private PrintWriter output = null;
	private OutputStream out = null;
	private InputStream in = null;
	private Socket socket = null;
	
	private String[] fileList;
	
	public ClientInterface()
	{
		SetUpUI();
		
		connect.setOnAction((e) -> 
		{
			try
			{
				//instantiating the streams and the socket
				socket = new Socket("Localhost",7455);
				in = socket.getInputStream();
				out = socket.getOutputStream();
				output = new PrintWriter(out);
				input = new BufferedReader(new InputStreamReader(in));
				
				txtResponse.appendText("Connected to server successfully\n");
			} 
			catch (UnknownHostException uh)
			{
				uh.printStackTrace();
			}
			catch (IOException io) 
			{
				io.printStackTrace();
			}
			
		});
		
		show.setOnAction((e) ->
		{
			//sending the command to the server
			output.println("DATA");
			output.flush();
			
			String response;
			
			try 
			{
				response = input.readLine();
				
				//splitting the strings
				fileList = response.split(":");
				
				for(int i = 0; i < fileList.length; i++)
				{
					txtArea.appendText(fileList[i]+"\n");
				}
				
			} 
			catch (IOException e1) 
			{
				e1.printStackTrace();
			}
		});
		
		getImage.setOnAction((e) -> 
		{
			//storing the id from the text field
			String id = txtID.getText();
			
			System.out.println(id);
			
			//sending the command to the server
			output.println("IMGRET "+id);
			output.flush();
			
			//Receiving the image sent from the server
			Image image = new Image(in);
			ImageView imageV = new ImageView();
			imageV.setFitHeight(500);
			imageV.setFitWidth(650);
			imageV.setImage(image);
			
			//adding and displaying the image on the UI
			add(imageV,0,10);
		});
		
		sendImage.setOnAction((e) -> 
		{
			//choosing a file from computer
			FileChooser fs = new FileChooser();
			File file = fs.showOpenDialog(null);
			
			//generating the ID for the image to be sent to the server
			int id = 0;
			id = fileList.length + 1;
			
			//the name of the image to be sent to the server
			String imgName = file.getName();
			
			//sending the command to the server
			output.println("IMGSEND " + id +" "+ imgName);
			output.flush();
			
			try 
			{
				//sending the image to the  server
				BufferedImage image = ImageIO.read(file);
				ImageIO.write(image, "JPG", out);
				System.out.println("Image sent to server");
				
				if(socket != null)
				{
					socket.close();
				}
			} 
			catch (IOException e1) 
			{
				e1.printStackTrace();
			}
			
			
		});
		
		if(socket != null)
		{
			try 
			{
				socket.close();
			} 
			catch (IOException e1) 
			{
				e1.printStackTrace();
			}
		}

	}
	
	private void SetUpUI()
	{
		setVgap(5);
		setHgap(5);
		
		HBox hb1 = new HBox();
		hb1.setSpacing(30);
		
		HBox hb2 = new HBox();
		hb2.setSpacing(10);
		
		HBox hb3 = new HBox();
		hb3.setSpacing(4);
		
		Label header = new Label("Client Image viewer");
		header.setFont(Font.font("Arial",FontWeight.BOLD,25));
		add(header,0,0,1,1);
		
				
		connect = new Button("Connect");
		connect.setPrefSize(150, 40);
		
		show = new Button("File List");
		show.setPrefSize(150,40);
		add(show,0,6);
		
		hb1.getChildren().addAll(connect);
		add(hb1,0,4,1,1);
		
		lblResponse = new Label("Response: ");
		lblResponse.setFont(Font.font("Arial",FontWeight.BOLD,20));
		
		txtResponse = new TextArea();
		txtResponse.setMaxSize(500, 20);
		
		hb3.getChildren().addAll(lblResponse,txtResponse);
		add(hb3,0,5);
		
		txtArea = new TextArea();
		add(txtArea,0,7,1,1);
		
		txtID = new TextField();
		txtID.setMaxWidth(100);
		txtID.setMaxHeight(40);
		
		getImage = new Button("Get Image");
		getImage.setPrefSize(150, 40);
		
		hb2.getChildren().addAll(getImage,txtID);
		add(hb2,0,8,1,1);
		

		sendImage = new Button("Send Image");
		sendImage.setPrefSize(150,40);
		add(sendImage,0,9,1,1);
		
	}
	
}
