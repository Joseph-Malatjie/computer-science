package Server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server 
{
	private ServerSocket sc;
	private boolean running = true;
	
	public Server(int port) 
	{
		try 
		{
			sc = new ServerSocket(port);
			System.out.println("Server waiting for a connection...");
			
			while(running)
			{
				Socket connection = sc.accept();
				System.out.println("Client connected on port " + port);
				Thread thread = new Thread(new ServerHandler(connection));
				thread.start();

			}
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			if(sc != null)
			{
				try 
				{
					sc.close();
				} 
				catch (IOException e) 
				{
					e.printStackTrace();
				}
			}
		}
	}
	
	public static void main(String[] args)
	{
		Server server = new Server(7455);
	}

}
