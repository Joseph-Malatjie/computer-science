#ifndef FILELIB_H_INCLUDED
#define FILELIB_H_INCLUDED

#include "UJRowMajorGrid.h"

#pragma pack(push)
#pragma pack(1)
struct RGBColour
{
    int Red;
    int Green;
    int Blue;
};
#pragma pack(pop)

void saveToCSV(string coloursFile, vector<RGBColour> Colours);
RGBColour loadFromCSV(string coloursFile, vector<RGBColour> colours);
void saveToDAT(vector<RGBColour> colours, string coloursFile);
int countRecords(string coloursFile);
RGBColour loadFromDATByIndex(string coloursFile, unsigned int index);
int countColoursFromDAT(string colourFile, RGBColour recColour);


#endif // FILELIB_H_INCLUDED
