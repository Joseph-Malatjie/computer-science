#include <iostream>

#include "UJRowMajorGrid.h"
#include "FileLib.h"

using namespace std;

 int main()
 {
 cout << "Creating Grid" << endl;
 UJRowMajorGrid<char> objGrid1;

 cout << "Testing one-dimensional indexing []" << endl;
 char chLetter = 'a';
 int intSize = objGrid1.getRows() * objGrid1.getCols();
 for(int i = 0; i < intSize; i++)
 {
 objGrid1[i] = chLetter++;
 }

 for(int i = 0; i < intSize; i++)
 {
 cout << objGrid1[i] << ' ';
 }
 cout << endl;
 cout << "Testing << operator" << endl;
 cout << objGrid1 << endl;

 cout << "Testing two-dimensional indexing (r, c)" << endl;

 for(int r = 0; r < objGrid1.getRows(); r++)
 {
 for(int c = 0; c < objGrid1.getCols(); c++)
 {
 cout << objGrid1(r, c) << ' ';
 }
 cout << endl;
 }

 cout << "Testing copy constructor" << endl;
 UJRowMajorGrid<char> objGrid2(objGrid1);

 cout << "Testing == operator " << endl;
 if(objGrid1 == objGrid2)
 {
 cout << "objGrid1 == objGrid2 is true" << endl;
 }

 cout << "Testing != operator" << endl;
 objGrid2[5] = '@';
 cout << "objGrid2 changed to " << objGrid2 << endl;
 if(objGrid1 != objGrid2)
 {
 cout << "objGrid1 != objGrid2 is true" << endl;
 }

 cout << "Testing assignment operator = " << endl;
 UJRowMajorGrid<char> objGrid3(5, 6, '#');
 objGrid2 = objGrid3;
 cout << "objGrid3 now equal to " << objGrid2 << endl;

 cout << "Testing chained assignment operator" << endl;
 objGrid1 = objGrid2 = objGrid3;
 cout << "Testing chained << operator" << endl;
 cout << objGrid1 << endl
 << objGrid2 << endl
 << objGrid3 << endl;

RGBColour recBlack;
recBlack.Red=0;
recBlack.Green=0;
recBlack.Blue=0;

RGBColour recRed;
recRed.Red=255;
recRed.Green=0;
recRed.Blue=0;

RGBColour recGreen;
recGreen.Red=0;
recGreen.Green=255;
recGreen.Blue=0;

RGBColour recBlue;
recBlue.Red=0;
recBlue.Green=0;
recBlue.Blue=255;

RGBColour recWhite;
recWhite.Red=255;
recWhite.Green=255;
recWhite.Blue=255;

vector<RGBColour>vColour;
vColour.push_back(recBlack);
vColour.push_back(recRed);
vColour.push_back(recGreen);
vColour.push_back(recBlue);
vColour.push_back(recWhite);

cout<<"Save to file"<<endl;
saveToCSV("pixels.dat",vColour);
loadFromCSV("pixels.dat",vColour);
cout<<"Number of records are :"<<countRecords("pixels.dat")<<endl;
cout<<"***Load record by index***"<<endl;
RGBColour lByIndex;
lByIndex=loadFromDATByIndex("pixels.dat",4);
// cout<<lByIndex<<endl;
cout<<"*****count colour record"<<endl;
cout<<countColoursFromDAT("pixels.dat",recBlack);

 return SUCCESS;
}
