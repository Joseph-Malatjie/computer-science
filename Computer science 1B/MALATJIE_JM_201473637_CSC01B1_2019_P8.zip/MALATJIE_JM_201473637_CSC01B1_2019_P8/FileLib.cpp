#include "FileLib.h"
#include <fstream>
#include <sstream>

void saveToCSV(string coloursFile, vector<RGBColour> Colours)
{
    fstream input;
    input.open(coloursFile, ios::binary | ios::out | ios::app);
    for(RGBColour s : Colours)
    {
        input.write(reinterpret_cast<char*>(&s), sizeof(RGBColour));
    }
    input.close();
}

RGBColour loadFromCSV(string coloursFile, vector<RGBColour> colours)
{
    RGBColour recColour;
    fstream input;
    input.open(coloursFile, ios::binary | ios::in);
    input.seekg(sizeof(RGBColour), ios::beg);
    for(int a=0;a<countRecords(coloursFile);a++)
    {
       input.read(reinterpret_cast<char*>(&recColour)
                    ,sizeof(RGBColour));
        cout <<"PIXEL"<<a<<""<<"_RED: "<< recColour.Red
             << " " <<"PIXEL"<<a<<"GREEN: "<<recColour.Green
             << " " <<"PIXEL"<<a<<"BLUE: "<< recColour.Blue<<" , " << endl;

    }

    input.close();
    return recColour;
}

void saveToDAT(vector<RGBColour> colours, string coloursFile)
{

}

int countRecords(string coloursFile)
{
    fstream input;
    input.open(coloursFile, ios::binary | ios::in);
    input.seekg(0, ios::end);
    int intBytes = input.tellg();
    input.close();

    return intBytes / sizeof(RGBColour);
}

RGBColour loadFromDATByIndex(string coloursFile, unsigned int index)
{
     RGBColour recColour;
    fstream input;
    input.open(coloursFile, ios::binary | ios::in);
    input.seekg(index * sizeof(RGBColour), ios::beg);
    input.read(reinterpret_cast<char*>(&recColour), sizeof(RGBColour));
    input.close();

    return recColour;
}

int countColoursFromDAT(string colourFile, RGBColour recColour)
{
    ifstream input(colourFile);
    string strLine = "";
    int intTotal = 0;
    while(getline(input, strLine))
    {
        stringstream ssLine;
        ssLine << strLine;
        int intNum = 0;
        while(ssLine >> intNum)
        {
            intTotal += intNum;
        }
    }

    input.close();
   return intTotal;

}
