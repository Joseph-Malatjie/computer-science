#ifndef BWIMAGE_H_INCLUDED
#define BWIMAGE_H_INCLUDED

#include "UJImage.h"
 //BWImage is-a UJImage
 class BWImage : public UJImage
 {
 public:

 BWImage();
 BWImage(int intRows, int intCols);

 //Note BWImage doesn't add any data members
 BWImage(const UJImage& objOriginal);
 BWImage(const BWImage& objOriginal);

 //Redefining toPPM
 string toPPM() const;

 ~BWImage();

 };

#endif // BWIMAGE_H_INCLUDED
