#include "WeightedGreyScale.h"
#include <cmath>
#include <iostream>
#include <sstream>

using namespace std;

WeightedGreyScale::WeightedGreyScale() : WeightedGreyScale(DEFAULT_ROWS, DEFAULT_COLS, DEFAULT_RED_WEIGHT, DEFAULT_GREEN_WEIGHT, DEFAULT_BLUE_WEIGHT)
{

}

WeightedGreyScale::WeightedGreyScale(int intRows,int intCols, double dblRedWeight, double dblGreenWeight, double dblBlueWeight) : UJImage(intRows, intCols)
{

    //Set all weights to 0 at start for sake of sum of weights tests
    _redWeight = _greenWeight = _blueWeight = 0;

    //Use mutator member functions for range tests
    setRedWeight(dblRedWeight);
    setGreenWeight(dblGreenWeight);
    setBlueWeight(dblBlueWeight);
}

WeightedGreyScale::WeightedGreyScale(const UJImage& objOriginal) : UJImage(objOriginal)
{
    setDefaultWeights();
}

WeightedGreyScale::WeightedGreyScale(const WeightedGreyScale& objOriginal) : UJImage(objOriginal)
 {
    setDefaultWeights();
 }

void WeightedGreyScale::setDefaultWeights()
{
    //Set all weights to 0 at start for sake of sum of weights tests
    _redWeight = _greenWeight = _blueWeight = 0;
    //Use mutator member functions for range tests
    setRedWeight(DEFAULT_RED_WEIGHT);
    setGreenWeight(DEFAULT_GREEN_WEIGHT);
    setBlueWeight(DEFAULT_BLUE_WEIGHT);
}

//Redefining toPPM
string WeightedGreyScale::toPPM() const
{
    stringstream ssPPM;
    ssPPM << "P2" << endl
          << _cols << ' ' << _rows << endl
          << 255 << endl;

    for(int r = 0; r < _rows; r++)
    {
        for(int c = 0; c < _cols; c++)
        {
            UJColour recPixel = _pixels[r][c];
            double dblWeightedAve = _redWeight * recPixel.intRed +
            _greenWeight * recPixel.intGreen +
            _blueWeight * recPixel.intBlue;
            int intAverage = round(dblWeightedAve);
            ssPPM << intAverage << ' ';
        }
            ssPPM << endl;
    }

    return ssPPM.str();

}

double WeightedGreyScale::getRedWeight() const
{
    return _redWeight;
}

double WeightedGreyScale::getGreenWeight() const
{
    return _greenWeight;
}

double WeightedGreyScale::getBlueWeight() const
{
    return _blueWeight;
}

void WeightedGreyScale::setRedWeight(double dblWeight)
{
    enforceWeightRange(dblWeight);
    _redWeight = dblWeight;
    enforceSumOfWeightsRange();
}

void WeightedGreyScale::setGreenWeight(double dblWeight)
{
    enforceWeightRange(dblWeight);
    _greenWeight = dblWeight;
    enforceSumOfWeightsRange();
}

void WeightedGreyScale::setBlueWeight(double dblWeight)
{
    enforceWeightRange(dblWeight);
    _blueWeight = dblWeight;
    enforceSumOfWeightsRange();
}

WeightedGreyScale::~WeightedGreyScale()
{
    freePixels();
}

void WeightedGreyScale::enforceWeightRange(double dblWeight) const
{
    if(dblWeight < 0.0 || dblWeight > 1.0)
    {
        cerr << "Weights must be in the range [0.0 - 1.0]" << endl;
        exit(ERROR_RANGE);
    }
}

void WeightedGreyScale::enforceSumOfWeightsRange() const
{
    double dblSum = _redWeight + _greenWeight + _blueWeight;
    if(dblSum > 1.0 || dblSum < 0.0)
    {
        cerr << "Sum of weights must be in the range [0.0 - 1.0]" << endl;
        exit(ERROR_RANGE);
    }

}
