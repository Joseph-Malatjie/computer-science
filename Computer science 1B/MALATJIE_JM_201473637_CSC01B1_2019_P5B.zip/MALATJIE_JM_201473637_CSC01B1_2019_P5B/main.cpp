#include "AverageGreyScale.h"
#include "UJColour.h"
#include "BWImage.h"
#include "UJImage.h"
#include "WeightedGreyScale.h"
#include "colourImage.h"

#include <cctype>
#include <iostream>

 using namespace std;

 int main(int argc, char* argv[])
 {
    if(argc != 2)
    {
        cerr << "Usage: " << argv[0] << " IMAGE-CONVERSION-TYPE (C, B, G, W)" << endl;
        exit(ERROR_CMD_ARG_COUNT);
    }


    char chConversionType = toupper(argv[1][0]);

    UJImage* Image;

    switch(chConversionType)
    {
        case 'C':
            {
                Image = new colourImage(500,500);

                UJColour recGreen = {2, 122, 60};

                UJColour recWhite = {255, 255, 255};

                UJColour recOrange = {245,158,66};

                for(int r = 0; r < Image->getRows(); r++)
                {
                    for(int c = 0; c < Image->getCols(); c++)
                    {
                        UJColour recColour;
                        if(c <= Image->getCols() / 3)
                        {
                            recColour = recGreen;
                        } else if((c > Image->getCols() / 3) &&
                            (c <= Image->getCols() *0.6666))
                        {
                            recColour = recWhite;
                        } else
                        {
                            recColour = recOrange;
                        }

                            Image->setPixel(r,c,recColour);
                    }
                }

                Image->printPolyPPM(Image);
            }
            break;

        case 'B':
        {

            Image = new BWImage(500,500);
            UJColour recGreen = {0, 135, 83};

            UJColour recWhite = {255, 255, 255};

            for(int r = 0; r < Image->getRows(); r++)
            {
                for(int c = 0; c < Image->getCols(); c++)
                {
                    UJColour recColour;
                    if(c <= Image->getCols() / 3)
                    {
                        recColour = recGreen;
                    } else if((c > Image->getCols() / 3) &&
                        (c <= Image->getCols() *0.6666))
                    {
                        recColour = recWhite;
                    } else
                    {
                        recColour = recGreen;
                    }

                        Image->setPixel(r,c,recColour);
                }
            }
            Image->printPolyPPM(Image);
        }
        break;

        case 'G':
        {
            Image = new AverageGreyScale(500,500);

            UJColour recGreen = {0, 135, 83};

            UJColour recWhite = {255, 255, 255};

            for(int r = 0; r < Image->getRows(); r++)
            {
                for(int c = 0; c < Image->getCols(); c++)
                {
                    UJColour recColour;
                    if(c <= Image->getCols() / 3)
                    {
                        recColour = recGreen;
                    } else if((c > Image->getCols() / 3) &&
                        (c <= Image->getCols() *0.6666))
                    {
                        recColour = recWhite;
                    } else
                    {
                        recColour = recGreen;
                    }

                        Image->setPixel(r,c,recColour);
                }
            }

            Image->printPolyPPM(Image);
        }
        break;

        case 'W':
        {
            Image = new WeightedGreyScale(500,500,0.3,0.59,0.11);
                        UJColour recGreen = {0, 135, 83};

            UJColour recWhite = {255, 255, 255};

            for(int r = 0; r < Image->getRows(); r++)
            {
                for(int c = 0; c < Image->getCols(); c++)
                {
                    UJColour recColour;
                    if(c <= Image->getCols() / 3)
                    {
                        recColour = recGreen;
                    } else if((c > Image->getCols() / 3) &&
                        (c <= Image->getCols() *0.6666))
                    {
                        recColour = recWhite;
                    } else
                    {
                        recColour = recGreen;
                    }

                        Image->setPixel(r,c,recColour);
                }
            }

            Image->printPolyPPM(Image);
        }
        break;

        default:
            cerr << "Invalid conversion type must be B, G, or A" << endl;
            exit(ERROR_CMD_ARG_VALUE);
    }

    return SUCCESS;
}
