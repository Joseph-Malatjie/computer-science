#include "BWImage.h"

 #include <sstream>

 using namespace std;

 BWImage::BWImage() : BWImage(DEFAULT_ROWS, DEFAULT_COLS)
 {
 }

 BWImage::BWImage(int intRows, int intCols) : UJImage(intRows, intCols)
 {
 }

 BWImage::BWImage(const UJImage& objOriginal) : UJImage(objOriginal)
 {
 }

 BWImage::BWImage(const BWImage& objOriginal) : UJImage(objOriginal)
 {
 }

 //Redefining toPPM
 string BWImage::toPPM() const
 {
 stringstream ssPPM;
 ssPPM << "P1" << endl
 << _cols << ' ' << _rows << endl;

 for(int r = 0; r < _rows; r++)
 {
 for(int c = 0; c < _cols; c++)
 {
 UJColour recPixel = _pixels[r][c];
 if((recPixel.intRed == 255) &&
 (recPixel.intGreen == 255) &&
 (recPixel.intBlue == 255))
 {
 ssPPM << 0;
 } else
 {
 ssPPM << 1;
 }
 ssPPM << ' ';
 }
 ssPPM << endl;
 }

 return ssPPM.str();

 }

 BWImage::~BWImage()
 {
 freePixels();
}
