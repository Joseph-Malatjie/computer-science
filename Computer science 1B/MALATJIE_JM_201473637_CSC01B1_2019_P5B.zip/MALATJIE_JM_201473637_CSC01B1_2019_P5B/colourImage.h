#ifndef COLOURIMAGE_H_INCLUDED
#define COLOURIMAGE_H_INCLUDED

#include "UJImage.h"

class colourImage : public UJImage
{
    public:
        colourImage();
        colourImage(const colourImage& objOriginal);
        colourImage(const UJImage& objOriginal);
        colourImage(int intRows, int intCols);

        //redefining the toPPM fuction
        string toPPM() const;

        ~colourImage();
};

#endif // COLOURIMAGE_H_INCLUDED
