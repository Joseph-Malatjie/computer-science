#include "colourImage.h"
#include <sstream>

colourImage::colourImage() : colourImage(DEFAULT_ROWS,DEFAULT_COLS)
{
}
colourImage::colourImage(const colourImage& objOriginal): UJImage(objOriginal)
{
}
colourImage::colourImage(const UJImage& objOriginal) : UJImage(objOriginal)
{
}
colourImage::colourImage(int intRows, int intCols) : UJImage(intRows,intCols)
{
}

//redefining the toPPM fuction
string colourImage::toPPM() const
{
     stringstream ssPPM;
    ssPPM << "P3" << endl
    << _cols << ' ' << _rows << endl
    << 255 << endl;
    for(int r = 0; r < _rows; r++)
    {
        for(int c = 0; c < _cols; c++)
        {
            ssPPM << _pixels[r][c].intRed << ' '
                  << _pixels[r][c].intGreen << ' '
                  << _pixels[r][c].intBlue << ' ';
        }
            ssPPM << endl;
    }
        return ssPPM.str();
}

colourImage::~colourImage()
{
    freePixels();
}
