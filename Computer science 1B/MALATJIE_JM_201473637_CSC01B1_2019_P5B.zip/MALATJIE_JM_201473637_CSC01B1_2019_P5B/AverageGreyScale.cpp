#include "AverageGreyScale.h"

#include <sstream>

using namespace std;

AverageGreyScale::AverageGreyScale() : AverageGreyScale(DEFAULT_ROWS, DEFAULT_COLS)
{
}

AverageGreyScale::AverageGreyScale(int intRows, int intCols) : UJImage(intRows, intCols)
{
}

AverageGreyScale::AverageGreyScale(const UJImage& objOriginal) : UJImage(objOriginal)
{
}

AverageGreyScale::AverageGreyScale(const AverageGreyScale& objOriginal) : UJImage(objOriginal)
{
}

//Redefining toPPM
 string AverageGreyScale::toPPM() const
 {
    stringstream ssPPM;
    ssPPM << "P2" << endl
    << _cols << ' ' << _rows << endl
    << 255 << endl;

    for(int r = 0; r < _rows; r++)
    {
        for(int c = 0; c < _cols; c++)
        {
            UJColour recPixel = _pixels[r][c];
            int intAverage = (recPixel.intRed +
            recPixel.intGreen +
            recPixel.intBlue) / 3;
            ssPPM << intAverage << ' ';
        }
        ssPPM << endl;
    }

    return ssPPM.str();

 }

 AverageGreyScale::~AverageGreyScale()
 {
    freePixels();
 }
