#ifndef UJCOLOUR_H_INCLUDED
#define UJCOLOUR_H_INCLUDED

enum StatusCode
{
    SUCCESS,
    ERROR_CONVERSION,
    ERROR_OUT_OF_BOUNDS,
    ERROR_RANGE,
    ERROR_CMD_ARG_COUNT,
    ERROR_CMD_ARG_VALUE
};
//Structure to represent a single colour value
struct UJColour
{
    unsigned short int intRed;
    unsigned short int intGreen;
    unsigned short int intBlue;
};
//Structure to represent the size of the imnage
struct Dimension
{
    int rows;
    int cols;
};
//Structure to represent a location in the image
struct Coordinate
{
    int row;
    int col;
};


#endif // UJCOLOUR_H_INCLUDED
