#ifndef UJIMAGE_H_INCLUDED
#define UJIMAGE_H_INCLUDED

#include "UJColour.h"

#include <string>

 using namespace std;

 class UJImage
 {
 public:
    UJImage();
    UJImage(int intRows, int intCols);
    UJImage(const UJImage& objOriginal);

    ///Accessor member functions
    int getRows() const;
    int getCols() const;
    UJColour getPixel(int intRow, int intCol) const;

    virtual string toPPM() const = 0;
    void printPolyPPM(UJImage* objOriginal);

    ///Mutator member function
    void setPixel(int intRow, int intCol, UJColour recColour);

    static const int MAX_SIZE = 10000000;
    static const int DEFAULT_ROWS = 768;
    static const int DEFAULT_COLS = 1024;

    ~UJImage();
 protected:
    void enforceRange(int intValue, int intMin, int intMax) const;
    void freePixels();
    UJColour** _pixels;
    int _rows;
    int _cols;
};


#endif // UJIMAGE_H_INCLUDED
