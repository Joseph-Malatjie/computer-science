#ifndef AVERAGEGREYSCALE_H_INCLUDED
#define AVERAGEGREYSCALE_H_INCLUDED

#include "UJImage.h"

 //AverageGreyScale is-a UJImage
 class AverageGreyScale : public UJImage
 {
    public:
        AverageGreyScale();
        AverageGreyScale(int intRows, int intCols);

        //Note AverageGreyScale doesn't add any data members
        AverageGreyScale(const UJImage& objOriginal);
        AverageGreyScale(const AverageGreyScale& objOriginal);

        //Redefining toPPM
        string toPPM() const;

        ~AverageGreyScale();
};

#endif // AVERAGEGREYSCALE_H_INCLUDED
