#ifndef WEIGHTEDGREYSCALE_H_INCLUDED
#define WEIGHTEDGREYSCALE_H_INCLUDED

#include "UJImage.h"
#include <string>

class WeightedGreyScale : public UJImage
{
    public:
        WeightedGreyScale();
        WeightedGreyScale(int intRows,int intCols, double dblRedWeight, double dblGreenWeight, double dblBlueWeight);
        WeightedGreyScale(const UJImage& objOriginal);
        WeightedGreyScale(const WeightedGreyScale& objOriginal);

        const double DEFAULT_RED_WEIGHT   = 0.3 ;
        const double DEFAULT_GREEN_WEIGHT = 0.59;
        const double DEFAULT_BLUE_WEIGHT  = 0.11;

       ~WeightedGreyScale();

       double getRedWeight() const;
       double getGreenWeight() const;
       double getBlueWeight() const;

       void enforceWeightRange(double dblWeight) const;
       void  enforceSumOfWeightsRange() const;
       string toPPM() const;

    private:
        double _redWeight;
        double _greenWeight;
        double _blueWeight;
        void setRedWeight(double dblWeight);
        void setGreenWeight(double dblWeight);
        void setBlueWeight(double dblWeight);
        void setDefaultWeights();

};

#endif // WEIGHTEDGREYSCALE_H_INCLUDED
