#include "UJImage.h"

#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

UJImage::UJImage() : UJImage(DEFAULT_ROWS, DEFAULT_COLS)
{
}

UJImage::UJImage(int intRows, int intCols)
{
    enforceRange(intRows, 0, MAX_SIZE);
    enforceRange(intCols, 0, MAX_SIZE);

    _rows = intRows;
    _cols = intCols;

    _pixels = new UJColour*[_rows];
    for(int r = 0; r < _rows; r++)
    {
        _pixels[r] = new UJColour[_cols];
        for(int c = 0; c < _cols; c++)
        {
            _pixels[r][c] = {0, 0, 0};
        }
    }
}

UJImage::UJImage(const UJImage& objOriginal) : UJImage(objOriginal._rows, objOriginal._cols)
{
    for(int r = 0; r < _rows; r++)
    {
        for(int c = 0; c < _cols; c++)
        {
            _pixels[r][c] = objOriginal._pixels[r][c];
        }
    }
}

int UJImage::getRows() const
{
    return _rows;
}

int UJImage::getCols() const
{
    return _cols;
}

UJColour UJImage::getPixel(int intRow, int intCol) const
{
    enforceRange(intRow, 0, _rows - 1);
    enforceRange(intCol, 0, _cols - 1);

    return _pixels[intRow][intCol];
}

///Mutator member function
void UJImage::setPixel(int intRow, int intCol, UJColour recColour)
{
    enforceRange(intRow, 0, _rows - 1);
    enforceRange(intCol, 0, _cols - 1);
    enforceRange(recColour.intRed, 0, 255);
    enforceRange(recColour.intGreen, 0, 255);
    enforceRange(recColour.intBlue, 0, 255);

    _pixels[intRow][intCol] = recColour;
}

void UJImage::printPolyPPM(UJImage* objOriginal)
{
    cout << objOriginal->toPPM() << endl;
}

void UJImage::freePixels()
{
    for(int r = 0; r < _rows; r++)
    {
        delete [] _pixels[r];
    }
        delete [] _pixels;
}

UJImage::~UJImage()
{
    freePixels();
}

void UJImage::enforceRange(int intValue, int intMin, int intMax) const
{
    if(intValue < intMin)
    {
        cerr << "Range error: " << intValue << " < " << intMin << endl;
        exit(ERROR_RANGE);
    }
    if(intValue > intMax)
    {
        cerr << "Range error: " << intValue << " > " << intMin << endl;
        exit(ERROR_RANGE);
    }
}
