#ifndef UJROWMAJORGRID_H_INCLUDED
#define UJROWMAJORGRID_H_INCLUDED

#include <iostream>
#include <vector>

 using namespace std;

 enum StatusCode
 {
 SUCCESS,
 ERROR_RANGE
 };

 struct Coordinate
 {
 int intRow;
 int intCol;
 };

 template <typename T>
 class UJRowMajorGrid
 {
 public:
 //Constructors
 UJRowMajorGrid();
 UJRowMajorGrid(int intRows, int intCols, char chDefaultValue);
 UJRowMajorGrid(const UJRowMajorGrid<T>& objOriginal);

 //Overloaded operators

 UJRowMajorGrid<T>& operator=(const UJRowMajorGrid<T>& objRHS);

 bool operator==(const UJRowMajorGrid<T>& objRHS);

 bool operator!=(const UJRowMajorGrid<T>& objRHS);


 /*
 cout << obj << endl;
 Due to LHS not being the class UJRowMajorGrid a
 non-member friend function is used
 */
 template <typename T1>
 friend ostream& operator<<(ostream& sLHS, const UJRowMajorGrid<T>& objRHS);

 T& operator[](int intIndex);

 T& operator()(int intRow, int intCol);

 //Class constants

 static const int MAX_SIZE = 100000000;
 static const int MIN_SIZE = 1;
 static const int DEFAULT_ROWS = 4;
 static const int DEFAULT_COLS = 3;
 static const char DEFAULT_VALUE = '\0';

 //Accessor member functions
 //Not actually required by the question
 T getValue(int intRow, int intCol) const;
 //Required for type to be useful
 int getRows() const;
 int getCols() const;

 //Mutator member functions
 //Not actually required by the question
 void setValue(int intRow, int intCol, char chValue);

 //Destructor
 ~UJRowMajorGrid();

 int _rows;
 int _cols;

 /*
 Students could also have had an underlying one-dimensional array and
 mapped the two-dimensional coordinates to the one-dimensional coordinate
 */
 T** _values;
 private:
 //Utility member functions
 void enforceRange(int intValue, int intMin, int intMax) const;
 void setup(int intRows, int intCols, char chDefaultValue);
 void freeState();
 void copyState(const UJRowMajorGrid& objOriginal);

 //Data members
 /*
 This vector contains the mappings between the one-dimensional
 coordinate and the two-dimensional coordinates as per row-major
 order. This could also have been achieved by way of the use of simple
 arithmetic including integer and modulo division.
 */
 vector<Coordinate> _dimensionMap;


 };

#include "UJRowMajorGrid.imp"
#endif // UJROWMAJORGRID_H_INCLUDED
