#include <iostream>

#include "UJRowMajorGrid.h"

using namespace std;

 int main()
 {
 cout << "Creating Grid" << endl;
 UJRowMajorGrid<char> objGrid1;

 cout << "Testing one-dimensional indexing []" << endl;
 char chLetter = 'a';
 int intSize = objGrid1.getRows() * objGrid1.getCols();
 for(int i = 0; i < intSize; i++)
 {
 objGrid1[i] = chLetter++;
 }

 for(int i = 0; i < intSize; i++)
 {
 cout << objGrid1[i] << ' ';
 }
 cout << endl;
 cout << "Testing << operator" << endl;
 cout << objGrid1 << endl;

 cout << "Testing two-dimensional indexing (r, c)" << endl;

 for(int r = 0; r < objGrid1.getRows(); r++)
 {
 for(int c = 0; c < objGrid1.getCols(); c++)
 {
 cout << objGrid1(r, c) << ' ';
 }
 cout << endl;
 }

 cout << "Testing copy constructor" << endl;
 UJRowMajorGrid<char> objGrid2(objGrid1);

 cout << "Testing == operator " << endl;
 if(objGrid1 == objGrid2)
 {
 cout << "objGrid1 == objGrid2 is true" << endl;
 }

 cout << "Testing != operator" << endl;
 objGrid2[5] = '@';
 cout << "objGrid2 changed to " << objGrid2 << endl;
 if(objGrid1 != objGrid2)
 {
 cout << "objGrid1 != objGrid2 is true" << endl;
 }

 cout << "Testing assignment operator = " << endl;
 UJRowMajorGrid<char> objGrid3(5, 6, '#');
 objGrid2 = objGrid3;
 cout << "objGrid3 now equal to " << objGrid2 << endl;

 cout << "Testing chained assignment operator" << endl;
 objGrid1 = objGrid2 = objGrid3;
 cout << "Testing chained << operator" << endl;
 cout << objGrid1 << endl
 << objGrid2 << endl
 << objGrid3 << endl;

 return SUCCESS;
}
