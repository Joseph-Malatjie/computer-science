#ifndef AVERAGEGRAYSCALE_H
#define AVERAGEGRAYSCALE_H
#include <string>
#include "UJImage.h"

class UJImage;
class AverageGrayscale : public UJImage
{
public:
    AverageGrayscale();
    AverageGrayscale(const UJImage& objOriginal);
    double CalculateMean(int& red ,int& green , int& blue);
    std::string toPGM_1(UJImage &objOriginal);
protected:

};


#endif // AVERAGEGRAYSCALE_H_INCLUDED
