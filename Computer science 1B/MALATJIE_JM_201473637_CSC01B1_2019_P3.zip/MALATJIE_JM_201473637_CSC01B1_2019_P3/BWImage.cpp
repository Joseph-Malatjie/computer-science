#include "UJImage.h"
#include "BWImage.h"
#include <iostream>
#include <sstream>
#include <cmath>

using namespace std;

string BWImage::toPBM(UJImage &objOriginal)
{
    stringstream ssPBM;
    ssPBM << "P1" << endl
          << objOriginal.getCols() << ' ' << objOriginal.getRows() << endl
          << 1 << endl;


    for(int r = 0; r < objOriginal.getRows(); r++)
    {
        for(int c = 0; c < objOriginal.getCols(); c++)
        {
            ssPBM << objOriginal.getPixel(r,c).intBlack << ' '
                  << objOriginal.getPixel(r,c).intWhite<< ' ';

        }
        ssPBM << endl;
    }
    return ssPBM.str();
}
