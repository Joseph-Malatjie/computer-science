#ifndef WEIGHTEDGRAYSCALE_H
#define WEIGHTEDGRAYSCALE_H
#include "UJImage.h"
#include <iostream>

using namespace std;
class UJImage;
class WeightedGrayscale : public UJImage
{
public:
    WeightedGrayscale();
    WeightedGrayscale(const UJImage& objOriginal);
    WeightedGrayscale(RGBColour& recDefaultWeight,double intWRed,double intWGreen,double intWBlue);
    string toPGM_2(UJImage &objOriginal);



};





#endif // WEIGHTEDGRAYSCALE_H_INCLUDED
