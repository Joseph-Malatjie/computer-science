#include "AverageGrayscale.h"
#include "UJImage.h"
#include <iostream>
#include <sstream>
#include <cmath>



using namespace std;

double AverageGrayscale::CalculateMean(int& red ,int& green , int& blue)
{

     RGBColour recRGB;
     recRGB.intRed = red;
     recRGB.intGreen = green;
     recRGB.intBlue = blue;


    double dblMean = ( recRGB.intRed + recRGB.intGreen + recRGB.intBlue )/3;

    return static_cast<unsigned int> (dblMean);
}

string AverageGrayscale::toPGM_1(UJImage &objOriginal)
{
    stringstream ssPGM;
     RGBColour recObjColour;
     recObjColour.intRed= 255;
     recObjColour.intGreen = 255;
     recObjColour.intBlue = 255;
     recObjColour.intGrayScale =0;


    ssPGM << "P2" << endl
          << objOriginal.getCols() << ' ' << objOriginal.getRows() << endl
          << CalculateMean(recObjColour.intRed,recObjColour.intGreen  , recObjColour.intBlue) << endl;

    for(int r = 0; r < objOriginal.getRows(); r++)
    {
        for(int c = 0; c < objOriginal.getCols(); c++)
        {
            ssPGM << objOriginal.getPixel(r,c).intGrayScale<< ' ';


        }
        ssPGM << endl;
    }

    return ssPGM.str();
}


