#include "WeightedGrayscale.h"
#include "UJImage.h"
#include <iostream>
#include <sstream>
#include "WeightedGrayscale.h"

using namespace std;
WeightedGrayscale::WeightedGrayscale(RGBColour &recDefaultWeight,double dblWRed,double dblWGreen,double dblWBlue)
{

    ///Setting up the weights for separated RGB;
     dblWRed = (0.3 )*static_cast<double>(recDefaultWeight.intRed);
     dblWGreen = (0.59)*static_cast<double>(recDefaultWeight.intGreen)  ;
     dblWBlue = (0.11)*static_cast<double>(recDefaultWeight.intBlue) ;
}

double UJImage::CalcWeightAverage(double dblWRed,double dblWGreen,double dblWBlue)
{
  double dblWeightedAverage = dblWRed + dblWGreen + dblWBlue;

  return static_cast<int>(dblWeightedAverage);
}

 string WeightedGrayscale::toPGM_2(UJImage &objOriginal)
{
    stringstream ssPGM;
    RGBColour recWeight;

    int intGrayScale = 0;
    double dblWRed = recWeight.intRed;
    double dblWGreen = recWeight.intGreen;
    double dblWBlue = recWeight.intBlue;
    ssPGM << "P2" << endl
          << objOriginal.getCols() << ' ' << objOriginal.getRows()<< endl
          << CalcWeightAverage(dblWRed,dblWGreen,dblWBlue)<< endl;

    for(int r = 0; r < objOriginal.getRows(); r++)
    {
        for(int c = 0; c < objOriginal.getCols(); c++)
        {
            ssPGM << objOriginal.getPixel(r,c).intGrayScale << ' ';


        }
        ssPGM << endl;
    }

    return ssPGM.str();
}

