#ifndef BWIMAGE_H_
#define BWIMAGE_H_
#include "UJImage.h"
#include <iostream>

class UJImage;
class BWImage : public UJImage
{
public:
    BWImage();
    BWImage(const UJImage& objOriginal);
    std::string toPBM(UJImage &objOriginal) ;

protected:


};


#endif // BWIMAGE_H_
