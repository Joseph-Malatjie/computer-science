#include <iostream>
#include "UJImage.h"
#include "WeightedGrayscale.h"
#include "BWImage.h"
#include "AverageGrayscale.h"
#include <string>
#include <cmath>
#include <cstdlib>

using namespace std;

int main()
{
    UJImage Image(800, 900);

    bool blnContinue = true;
    char chChoice = '\0';
    do
    {
    system("cls");

    cout << "SELECT ANY OF THE OPTIONS BELOW: " << endl
         << "a)Print a Black-White Image." << endl
         << "b)Print an Average-Grayscale Image." << endl
         << "c)Print a Weighted-Grayscale Image." << endl
         << "x)Terminate the program" << endl;

    cin >> chChoice;
    switch(chChoice)
    {
    case 'A':
    case 'a':
    {

    RGBColour recGreen;
    recGreen.intRed =0;
    recGreen.intGreen = 255;
    recGreen.intBlue = 0;

    RGBColour recWhite;
    recWhite.intBlue = 255;
    recWhite.intRed = 255;
    recWhite.intGreen = 255;

    for(int r = 0; r < Image.getRows(); r++)
    {
        for(int c = 0; c < Image.getCols(); c++)
        {
            RGBColour recColour;
            if(c <= Image.getCols() / 3)
            {
                recColour = recGreen;
            } else if((c > Image.getCols() / 3) &&
                      (c <= Image.getCols() *0.6666))
            {
                recColour = recWhite;
            } else
            {
                recColour = recGreen;
            }

            Image.setPixel(r,c,recColour);
        }
    }
        cout<< Image.toPBM() << endl;
        system("pause");
    }
    break;

    case 'B':
    case 'b':
    {
            RGBColour recGreen;
    recGreen.intRed =0;
    recGreen.intGreen = 255;
    recGreen.intBlue = 0;

    RGBColour recWhite;
    recWhite.intBlue = 255;
    recWhite.intRed = 255;
    recWhite.intGreen = 255;

    for(int r = 0; r < Image.getRows(); r++)
    {
        for(int c = 0; c < Image.getCols(); c++)
        {
            RGBColour recColour;
            if(c <= Image.getCols() / 3)
            {
                recColour = recGreen;
            } else if((c > Image.getCols() / 3) &&
                      (c <= Image.getCols() *0.6666))
            {
                recColour = recWhite;
            } else
            {
                recColour = recGreen;
            }

            Image.setPixel(r,c,recColour);
        }
    }
        cout << Image.toPGM_1() << endl;
        system("pause");
    }
    break;

    case 'C':
    case 'c':
    {
            RGBColour recGreen;
    recGreen.intRed =0;
    recGreen.intGreen = 255;
    recGreen.intBlue = 0;

    RGBColour recWhite;
    recWhite.intBlue = 255;
    recWhite.intRed = 255;
    recWhite.intGreen = 255;

    for(int r = 0; r < Image.getRows(); r++)
    {
        for(int c = 0; c < Image.getCols(); c++)
        {
            RGBColour recColour;
            if(c <= Image.getCols() / 3)
            {
                recColour = recGreen;
            } else if((c > Image.getCols() / 3) &&
                      (c <= Image.getCols() *0.6666))
            {
                recColour = recWhite;
            } else
            {
                recColour = recGreen;
            }

            Image.setPixel(r,c,recColour);
        }
    }
        cout << Image.toPGM_2() << endl;
        system("pause");
    }
    break;

    case 'X':
    case 'x':
    {
    blnContinue = false;
    }
    break;

    }

    }while(blnContinue);

    return 0;
}
