#ifndef UJIMAGE_H
#define UJIMAGE_H
#include <iostream>
#include <string>

const int MAX_DIMENSION = 1000000;

enum StatusCode
{
    SUCCESS,
    ERROR_RANGE
};

///Plain old data structure (PODS)
struct RGBColour
{
    ///PPM Colours
    int intRed;
    int intGreen;
    int intBlue;

    ///PGM Color
    int intGrayScale;

    ///PBM Colours
    int intBlack = 0;
    int intWhite = 0;
};

typedef RGBColour* RGBColourRow;
typedef RGBColourRow* ColourArray;

class BWImage;
class WeightedGrayscale;
class AverageGrayscale;

class UJImage
{
public:
    UJImage();
    UJImage(int intRows, int intCols);
    UJImage(const UJImage& objOriginal);

    //Accessor (getter)
    int getRows() ;
    int getCols() ;
    RGBColour getPixel(int intRow, int intCol) ;
    std::string toPBM();
    std::string toPGM_1();
    std::string toPGM_2();

    //Mutator (setter)
    void setPixel(int intRow, int intCol, RGBColour recColour);

    static const int DEFAULT_ROWS = 768;
    static const int DEFAULT_COLS = 1024;

    ~UJImage();
protected:
    void enforceRange(int intValue, int intMin, int intMax) const;
    double CalculateMean(int& red ,int& green , int& blue);
    double CalcWeightAverage(double dblWRed,double dblWGreen,double dblWBlue);

    ColourArray _pixels;

    int _rows;
    int _cols;
private:

};

#endif // UJIMAGE_H
