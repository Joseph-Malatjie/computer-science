#ifndef COMMONLIB_H_INCLUDED
#define COMMONLIB_H_INCLUDED

enum StatusCode
{
    SUCCESS,
    ERROR_CONVERSION,
    ERROR_OUT_OF_BOUNDS
};
//Structure to represent a single colour value
struct RGBColour
{
    unsigned short int red;
    unsigned short int green;
    unsigned short int blue;
};
//Structure to represent the size of the imnage
struct Dimension
{
    int rows;
    int cols;
};
//Structure to represent a location in the image
struct Coordinate
{
    int row;
    int col;
};


#endif // COMMONLIB_H_INCLUDED
