#include "UJImage.h"
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <cmath>

using namespace std;

UJImage::UJImage() : UJImage(DEFAULT_ROWS, DEFAULT_COLS)
{
}

UJImage::UJImage(int intRows, int intCols)
{
    enforceRange(intRows, 1, MAX_DIMENSION);
    enforceRange(intCols, 1, MAX_DIMENSION);
    _rows = intRows;
    _cols = intCols;

    RGBColour recCoulor;
    recCoulor.intRed = 0;
    recCoulor.intGreen = 0;
    recCoulor.intBlue = 0;

    _pixels = new RGBColourRow[_rows];
    for(int r = 0; r < _rows; r++)
    {
        _pixels[r] = new RGBColour[_cols];
        for(int c = 0; c < _cols; c++)
        {
            _pixels[r][c] = recCoulor;
        }
    }
}

UJImage::UJImage(const UJImage& objOriginal) : UJImage(objOriginal._rows, objOriginal._cols)
{
    for(int r = 0; r < _rows; r++)
    {
        for(int c = 0; c < _cols; c++)
        {
            _pixels[r][c] = objOriginal._pixels[r][c];
        }
    }
}

int UJImage::getRows()
{
    return _rows;
}

string UJImage::toPGM_1()
{
    stringstream ssPGM;

    ssPGM << "P2" << endl
          << _cols << ' ' << _rows << endl
          << 255 << endl;

    for(int r = 0; r < _rows; r++)
    {
        for(int c = 0; c < _cols; c++)
        {
            ssPGM <<_pixels[r][c].intRed<< ' '
                  <<_pixels[r][c].intGreen<<' '
                  <<_pixels[r][c].intBlue<<' ';
        }
        ssPGM << endl;
    }

    return ssPGM.str();
}
string UJImage::toPGM_2()
{
    stringstream ssPGM;
    ssPGM << "P2" << endl
          << _cols << ' ' << _rows << endl
          << 255 << endl;

    for(int r = 0; r < _rows; r++)
    {
        for(int c = 0; c < _cols; c++)
        {
            ssPGM <<_pixels[r][c].intGrayScale<< ' ';


        }
        ssPGM << endl;
    }

    return ssPGM.str();
}


int UJImage::getCols()
{
    return _cols;
}

RGBColour UJImage::getPixel(int intRow, int intCol)
{
    enforceRange(intRow, 0, _rows - 1);
    enforceRange(intCol, 0, _cols - 1);

    return _pixels[intRow][intCol];
}

void UJImage::setPixel(int intRow, int intCol, RGBColour recColour)
{
    enforceRange(intRow, 0, _rows - 1);
    enforceRange(intCol, 0, _cols - 1);

    _pixels[intRow][intCol] = recColour;
}

UJImage::~UJImage()
{
    for(int r = 0; r < _rows; r++)
    {
        delete [] _pixels[r];
    }
    delete [] _pixels;
}

string UJImage::toPBM()
{
    stringstream ssPBM;
    RGBColour recBW;
    int intBlack = recBW.intBlack;
    int intWhite = recBW.intWhite;
    ssPBM << "P1" << endl
          << _rows << ' ' << _cols << endl
          << 1 << endl;

    for(int r = 0; r < _rows; r++)
    {
        for(int c = 0; c < _cols; c++)
        {
            ssPBM << _pixels[r][c].intBlack << ' ' /// Black pixel;
                  << _pixels[r][c].intWhite<< ' '; ///White pixel;

        }
        ssPBM << endl;
    }
    return ssPBM.str();
}

void UJImage::enforceRange(int intValue, int intMin, int intMax) const
{
    if(intValue < intMin)
    {
        cerr << "Error: " << intValue << " < " << intMin;
        exit(ERROR_RANGE);
    }
    if(intValue > intMax)
    {
        cerr << "Error: " << intValue << " > " << intMax;
        exit(ERROR_RANGE);
    }
}
