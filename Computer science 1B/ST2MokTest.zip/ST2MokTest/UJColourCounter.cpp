#include "UJColourCounter.h"

UJColourCounter::UJColourCounter()
{

}

int UJColourCounter::countColour(const UJImage& objImage, RGBColour recColour)
{
    int intTotal = 0;
    int rows = objImage.getrows();
    int cols = objImage.getcols();

    for(int r = 0; r < rows; r++)
    {
        for(int c = 0; c < cols; c++)
        {
            RGBColour recPixel = objImage.getPixel(r,c);
            if((recPixel.red == recColour.red) &&
               (recPixel.green == recColour.blue) &&
               (recPixel.blue == recColour.blue))
            {
                intTotal++;
            }
        }
    }

    return intTotal;
}

UJColourCounter::~UJColourCounter()
{
    //dtor
}
