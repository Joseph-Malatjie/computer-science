#ifndef UJEXCEPTIONS_H
#define UJEXCEPTIONS_H

#include "UJImage.h"
class UJExceptions
{
    public:
        UJExceptions();
        virtual void respond() = 0;
};

class UJColourException : public UJExceptions
{
    public:
        UJColourException();
        UJColourException(RGBColour recColour);

        virtual void respond();

    private:
        RGBColour colour;
};

class UJDimesionException : public UJExceptions
{
    public:
        UJDimesionException();
        UJDimesionException(bool blnRow);

        virtual void respond();

    private:
        bool isRow;
};

#endif // UJEXCEPTIONS_H
