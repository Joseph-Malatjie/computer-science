#ifndef UJCOLOURCOUNTER_H
#define UJCOLOURCOUNTER_H

#include "UJImage.h"

class UJImage;
struct RGBColour;

class UJColourCounter
{
    public:
        UJColourCounter();
        int countColour(const UJImage& objImage, RGBColour recColour);

        virtual ~UJColourCounter();

    private:
};

#endif // UJCOLOURCOUNTER_H
