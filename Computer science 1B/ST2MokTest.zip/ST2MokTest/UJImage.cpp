#include "UJImage.h"
#include "UJExceptions.h"
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;

UJImage::UJImage()
{
    Init(DEFAULT_ROWS, DEFAULT_COLS);
}

UJImage::~UJImage()
{
    freePixels();
}

UJImage::UJImage(int intRows, int intCols)
{
    Init(intRows,intCols);
}

UJImage::UJImage(const UJImage& objOriginal)
{
    Init(objOriginal.rows, objOriginal.cols);

    for(int r = 0; r < rows; r++)
    {
        for(int c = 0; c < cols; c++)
        {
            pixels[r][c] = objOriginal.pixels[r][c];
        }
    }
}

UJImage& UJImage::operator=(const UJImage& objRHS)
{
    if(this != &objRHS)
    {
        freePixels();
        Init(objRHS.rows, objRHS.cols);
        for(int r = 0; r < rows; r++)
        {
            for(int c = 0; c < cols; c++)
            {
                pixels[r][c] = objRHS.pixels[r][c];
            }
        }
    }
    return *this;
}

ostream& operator<<(ostream& sLHS, const UJImage& objRHs)
{
   sLHS << "P3" << endl
        << objRHs.getrows() << ' ' << objRHs.getcols() << endl
        << 255 << endl;

    for(int r = 0; r < objRHs.getrows(); r++)
    {
        for(int c = 0; c < objRHs.getcols(); c++)
        {
            RGBColour recColour = objRHs.getPixel(r,c);
            sLHS << recColour.red << ' '
                 << recColour.green << ' '
                 << recColour.blue << ' ';
        }
        sLHS << endl;
    }
    return sLHS;
}

istream& operator>>(istream& sLHS, UJImage& objRHS)
{
    string strP3, str255;
    int intRows, intCols;

    sLHS >> strP3 >> intCols >> intRows >> str255;
    objRHS.freePixels();
    objRHS.Init(intRows,intCols);
    for(int r = 0; r < intRows; r++)
    {
        for(int c = 0; c < intCols; c++)
        {
            sLHS >> objRHS.pixels[r][c].red
                 >> objRHS.pixels[r][c].green
                 >> objRHS.pixels[r][c].blue;
        }
    }
    return sLHS;
}

int UJImage::countRecords(string strFileName)
{
    fstream flcount;
    flcount.open(strFileName.c_str(), ios::binary | ios::in);
    int intBytes = 0;
    flcount.seekp(0, ios::end);
    intBytes = flcount.tellg();
    flcount.close();
    return intBytes / sizeof(RGBColour);
}

void UJImage::loadFromDAT(string strFileName)
{
    fstream fsInput;
    fsInput.open(strFileName.c_str(), ios::binary | ios::in);
    freePixels();
    Init(600,800);
    RGBColour recColour;
    for(int r = 0; r < rows; r++)
    {
        for(int c = 0; c < cols; c++)
        {
            fsInput.read(reinterpret_cast<char*>(&recColour), sizeof(RGBColour));
            pixels[r][c] = recColour;
        }
    }
    fsInput.close();
}


int UJImage::getrows() const
{
    return rows;
}

int UJImage::getcols() const
{
    return cols;
}

string UJImage::toPPM()
{
    stringstream ssPPM;

    ssPPM << "P3" << endl
          << rows << ' ' << cols << endl
          << 255 << endl;
    for(int r = 0; r < rows; r++)
    {
        for(int c = 0; c < cols; c++)
        {
            ssPPM << pixels[r][c].red << ' '
                  << pixels[r][c].green << ' '
                  << pixels[r][c].blue << ' ';
        }
        ssPPM << endl;
    }

    return ssPPM.str();
}

void UJImage::setPixel(int intRow, int intCol, RGBColour recColour)
{
    enforceRange(intRow, 0, rows, true);
    enforceRange(intCol, 0, cols, false);
    enforceColour(recColour);

    pixels[intRow][intCol] = recColour;
}

RGBColour UJImage::getPixel(int intRow, int intCol) const
{
    enforceRange(intRow, 0, rows, true);
    enforceRange(intCol, 0, cols, false);

    return pixels[intRow][intCol];
}

void UJImage::enforceRange(int intValue, int intMin, int intMax, bool blnRow) const
{
    if((intValue < intMin) || (intValue > intMax + 1) )
    {
        throw UJDimesionException(blnRow);
    }
}

void UJImage::enforceColour(RGBColour recColour)
{
    if(recColour.red < 0 || recColour.red > 255 ||
       recColour.green < 0 || recColour.green > 255 ||
       recColour.blue < 0 || recColour.blue > 255)
    {
        throw UJColourException(recColour);
    }
}

void UJImage::Init(int intRows, int intCols)
{
    enforceRange(intRows,0,INT_MAX-1, true);
    rows = intRows;
    enforceRange(intCols,0,INT_MAX-1, false);
    cols = intCols;

    pixels = new RGBColour*[rows];

    for(int r = 0; r < rows; r++)
    {
        pixels[r] = new RGBColour[cols];
        for(int c = 0; c < cols; c++)
        {
            pixels[r][c].red = 0;
            pixels[r][c].green = 0;
            pixels[r][c].blue = 0;
        }
    }
    objCounter = new UJColourCounter;

}

int UJImage::countColour(RGBColour recColour)
{
    return objCounter->countColour(*this ,recColour); //delegation
}

void UJImage::freePixels()
{
    for(int r = 0; r < rows; r++)
        delete[] pixels[r];
    delete [] pixels;
    delete objCounter;
}
