#include "UJImage.h"
#include "UJExceptions.h"

#include <iostream>
#include <fstream>

using namespace std;

void processUJException(UJExceptions& e)
{
    e.respond();
}

int main()
{
    try
    {
        UJImage objImage(10,8);

        RGBColour recBlack;
        recBlack.red = 0;
        recBlack.green = 0;
        recBlack.blue = 0;

        cout << "Pixel count: " << objImage.countColour(recBlack) << endl;
        UJImage objClone;
        objClone = objImage;
        cout << objClone << endl;

        ifstream fsIn;
        fsIn.open("test.ppm");
        fsIn >> objClone;
        cout << objClone << endl;

        cout << "Num Pixels: " << objImage.countRecords("pixels.dat") << endl;

        objClone.loadFromDAT("pixels.dat");

        cout << objClone << endl;
    }

    catch(UJColourException& e)
    {
       cout << "UJColour exception" << endl;
       processUJException(e);
    }

    catch(UJDimesionException& e)
    {
        cout << "Dimension exception" << endl;
        processUJException(e);
    }

    catch(UJExceptions& e)
    {
        cerr << " A new kind of exception caught" << endl;
        processUJException(e);
    }

    catch(...)
    {
        cerr << "didn't expect this" << endl;
    }

    return 0;
}
