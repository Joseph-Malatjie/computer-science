#ifndef UJIMAGE_H
#define UJIMAGE_H

#include <string>
#include <iostream>

#include "UJColourCounter.h"
class UJColourCounter;

#pragma pack(push)
#pragma pack(1)
struct RGBColour
{
    int red = 0;
    int green = 0;
    int blue = 0;
};
#pragma pack(pop)

using namespace std;

class UJImage
{
    public:
        UJImage();
        UJImage(int intRows, int intCols);
        UJImage(const UJImage& objOriginal);
        virtual ~UJImage();

        static const int DEFAULT_ROWS = 20;
        static const int DEFAULT_COLS = 30;
        static const int MAX_VALUE = 1000000;
        static const int MIN_VALUE = 0;

        UJImage& operator=(const UJImage& objRHS);
        friend ostream& operator<<(ostream& sLHS, const UJImage& objRHs);
        friend istream& operator>>(istream& sLHS, UJImage& objRHS);

        int countRecords(string strFileName);
        void loadFromDAT(string strFileName);

        int getrows() const;
        int getcols() const;
        string toPPM();
        void setPixel(int intRow, int intCol, RGBColour recColour);
        RGBColour getPixel(int intRow, int intCol) const;
        int countColour(RGBColour recColour);


    private:

        int rows;
        int cols;

        void enforceRange(int intValue, int intMin, int intMax, bool blnRow) const;
        void enforceColour(RGBColour recColour);
        void Init(int intRows, int intCols);
        void freePixels();
        RGBColour** pixels;
        UJColourCounter* objCounter;
};

#endif // UJIMAGE_H
