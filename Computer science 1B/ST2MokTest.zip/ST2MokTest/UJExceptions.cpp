#include "UJExceptions.h"

#include <iostream>

using namespace std;

UJExceptions::UJExceptions()
{
    //ctor
}

UJColourException::UJColourException()
{

}

UJColourException::UJColourException(RGBColour recColour)
{
    colour = recColour;
}

void UJColourException::respond()
{
    cerr << "The following colour caused the error: " << colour.red << ' '
                                                      << colour.green << ' '
                                                      << colour.blue << endl;
}

UJDimesionException::UJDimesionException()
{

}

UJDimesionException::UJDimesionException(bool blnRow)
{
    isRow = blnRow;
}

void UJDimesionException::respond()
{
    if(isRow)
        cerr << "The row component caused the error" << endl;
    else
        cerr << "The column component caused the error" << endl;

}
