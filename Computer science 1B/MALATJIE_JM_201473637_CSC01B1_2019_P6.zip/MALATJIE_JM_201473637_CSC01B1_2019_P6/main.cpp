#include <iostream>
#include "UJRowMajorGrid.h"

using namespace std;

int main()
{
    int intRows= 0;
    int intCols=3;

    cout << "Enter number of rows"<<endl;
    cin>>intRows;

    if(intRows > 9)
    {
        cerr << "Number of rows can not be greater than 9 or less than 1" << endl;
        cout << "Enter number of rows"<<endl;
        cin>>intRows;
        cout<<endl;
    }

    UJRowMajorGrid objGrid(intRows,intCols);
    UJRowMajorGrid objGrid2(intRows,intCols);

    if(objGrid==objGrid2)
    {
        cout<<"The objects are equal"<<endl;
        cout<<endl;
        cout<<"objGrid 1" << endl;
        cout<<objGrid<<endl;
        cout<<endl;
        cout<<"objGrid 2" << endl;
        cout<<objGrid2<<endl;
    }

    cout<<"objGrid"<<endl;
    objGrid[3]='D';

    cout<<objGrid<<endl;
    cout<<endl;

    if(objGrid!=objGrid2)
    {
        cout<<"The objects are not equal"<<endl;
        cout<<endl;
        cout<<"objGrid 1" << endl;
        cout<<objGrid<<endl;
        cout<<endl;

        cout<<"objGrid 2"<<endl;
        cout<<objGrid2 <<endl;
    }
    cout<<endl;
    cout<<"Row 1:"<<"Column 2: "<<objGrid(1,2);

    return Status_Code::SUCCESS;
}
