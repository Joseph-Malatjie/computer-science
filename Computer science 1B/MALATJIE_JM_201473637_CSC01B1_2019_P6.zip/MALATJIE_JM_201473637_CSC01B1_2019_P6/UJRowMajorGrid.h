#ifndef UJROWMAJORGRID_H_INCLUDED
#define UJROWMAJORGRID_H_INCLUDED

#include "UJCommonTypes.h"
#include <cstdlib>
#include <sstream>
#include <cassert>
#include <string>
#include <iostream>

using namespace std;

class UJRowMajorGrid
{
public:

    UJRowMajorGrid();
    UJRowMajorGrid(const UJRowMajorGrid& objOriginal);
    UJRowMajorGrid(int intRows, int intCols);
    ~UJRowMajorGrid();

    void freeArray();

    const int MAX_ROWS = 9;
    const int MAX_COLS = 3;

    //Accessor function
    int getRows() const;
    int getCols() const;

    //Mutator functions
    void setRows(int intValue);
    void setCols(int intValue);
    void allocateChars(int intRows,int intCols);

    //Assigning operator
    UJRowMajorGrid& operator=(const UJRowMajorGrid& objRHS);

    //Equality operator
    bool operator==(const UJRowMajorGrid& objRHS) const;
    bool operator!=(const UJRowMajorGrid& objRHS)const;

    //ostream operator
    friend ostream& operator<<(ostream& osLHS,const UJRowMajorGrid& objRHS);

    //indexing operator
    char& operator[](int intRow) const;

    //invocation operator
    char operator()(int intRow,int intCol) const;


private:

    int _Rows;
    int _Cols;
    int _Index = 0;
    char* _ch1DARRAY ;
    char** _ch2DARRAY ;
    char* rowMajorARRAY ;
    void enforceRange(int intValue,int intMin,int intMax) const;

};
#endif // UJROWMAJORGRID_H_INCLUDED
