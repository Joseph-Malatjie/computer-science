#include "UJRowMajorGrid.h"
#include "UJCommonTypes.h"

UJRowMajorGrid::UJRowMajorGrid()
{
}

UJRowMajorGrid::UJRowMajorGrid(const UJRowMajorGrid& objOriginal):UJRowMajorGrid(objOriginal._Rows, objOriginal._Cols)
{
    for(int r = 0; r < _Rows;r++)
    {
        for(int c = 0; c < _Cols; c++)
        {
            _ch2DARRAY[r][c] = objOriginal._ch2DARRAY[r][c];
        }
    }
}

UJRowMajorGrid::UJRowMajorGrid(int intRows, int intCols)
{
    allocateChars(intRows,intCols);
}

//Accessor function
int UJRowMajorGrid::getRows() const
{
    return _Rows;
}

int UJRowMajorGrid::getCols() const
{
    return _Cols;
}

//Ensuring that the values are within the range
void UJRowMajorGrid:: enforceRange(int intValue,int intMin,int intMax) const
{
    if(intValue<intMin)
    {
        cerr<< "Range 1 error" << intValue <<endl;
        exit(Status_Code::ERROR_RANGE);
    }

    if(intValue>intMax)
    {
        cerr << "Range 2 error" << intValue <<endl;
        exit(Status_Code::ERROR_RANGE);
    }
}

//Mutator functions
void UJRowMajorGrid::setRows(int intValue)
{
    _Rows = intValue;
}

void UJRowMajorGrid::setCols(int intValue)
{
    _Cols = intValue;
}

void UJRowMajorGrid::allocateChars(int intRows,int intCols)
{
    enforceRange(intRows,1,MAX_ROWS);
    enforceRange(intCols,1,MAX_COLS);

    setRows(intRows);
    setCols(intCols);

    _ch1DARRAY = new char[_Rows*intCols];

    for(int r=0;r<(_Rows*intCols);r++)
    {
        _ch1DARRAY[r]=CHARCTERS[r];

    }
        _ch2DARRAY = new char*[_Rows];

        for(int r=0;r<_Rows;r++)
        {
            _ch2DARRAY[r]= new char[_Cols];

            for(int c=0;c<_Cols;c++)
            {
                _ch2DARRAY[r][c]=_ch1DARRAY[_Index];
                ++_Index;
            }
        }

}

//Assigning operator
UJRowMajorGrid& UJRowMajorGrid::operator=(const UJRowMajorGrid& objRHS)
{
    if(this != &objRHS)
    {
        freeArray();
        _Rows=objRHS._Rows;
        _Cols=objRHS._Cols;

        allocateChars(_Rows,_Cols);

        for(int r=0;r<_Rows;r++)
        {
           for(int c=0;c<_Cols;c++)
            {
              _ch2DARRAY[r][c]=objRHS._ch2DARRAY[r][c];

            }
        }
    }
  return *this;
}

//Equality operator
bool UJRowMajorGrid::operator==(const UJRowMajorGrid& objRHS) const
{
    if(_Rows != objRHS._Rows) return false;
    if(_Cols != objRHS._Cols) return false;

    for(int r=0;r<_Rows;r++)
    {
        for(int c=0;c<_Cols;c++)
        {
            if(_ch2DARRAY[r][c] != objRHS._ch2DARRAY[r][c]) return false ;
        }
    }
    return true;
}

bool UJRowMajorGrid::operator!=(const UJRowMajorGrid& objRHS)const
{
    if(_Rows !=objRHS._Rows)
    {
        return false;
    }
    if(_Cols != objRHS._Cols)
    {
        return false;
    }
    for( int r = 0;r< _Rows; r++)
    {
      for( int c = 0;c< _Cols; c++)
      {
        if((_ch2DARRAY[r][c]) != (objRHS._ch2DARRAY[r][c]))
        return true;
      }
    }
    return true;
}

//ostream operator
ostream& operator<<(ostream& osLHS,const UJRowMajorGrid& objRHS)
{

    for(int r=0;r<objRHS._Rows;r++)
    {
        for(int c=0;c<objRHS._Cols;c++)
        {
            osLHS<<objRHS._ch2DARRAY[r][c]<<' ';
        }
        osLHS<<endl;
    }
   return osLHS;
}

//indexing operator
char& UJRowMajorGrid::operator[](int intRow) const
{
    // Ensuring that the index provided is within the bounds of the array.
    if(intRow < 0 || intRow >= MAX_ROWS)
    {
        cerr << "Invalid index, " << _Index << "!!!!!!" << endl;
        exit(-1);
    }
    return _ch1DARRAY[intRow];
}

void UJRowMajorGrid::freeArray()
{
    for(int r=0;r<_Rows;r++)
    {
        delete[] _ch2DARRAY[r];
    }

    delete _ch2DARRAY;
    _ch2DARRAY=nullptr;

}

//invocation operator
char UJRowMajorGrid::operator()(int intRow,int intCol) const
{
    return _ch2DARRAY[intRow][intCol];
}


UJRowMajorGrid::~UJRowMajorGrid()
{
    freeArray();
}
