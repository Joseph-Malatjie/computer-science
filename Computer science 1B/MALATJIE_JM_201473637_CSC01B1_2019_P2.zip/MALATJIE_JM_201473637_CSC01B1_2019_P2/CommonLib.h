#ifndef COMMONLIB_H_INCLUDED
#define COMMONLIB_H_INCLUDED

#include <string>

enum StatusCode
{
    SUCCESS,
    ERROR_CMD_ARG_COUNT,
    ERROR_CONVERSION,
    ERROR_RANGE,
    ERROR_SEED_COUNT,
    ERROR_SEED_UNIQUENESS
};

int rangedRandom(int intMin, int intMax);
int convertToInt(std::string strNumber);

#endif // COMMONLIB_H_INCLUDED
