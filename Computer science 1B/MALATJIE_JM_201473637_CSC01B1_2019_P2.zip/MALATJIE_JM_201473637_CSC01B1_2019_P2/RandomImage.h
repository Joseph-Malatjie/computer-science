#ifndef RANDOMIMAGE_H_INCLUDED
#define RANDOMIMAGE_H_INCLUDED

#include "UJIMAGE.h"
#include <iostream>
#include <vector>

using namespace std;

struct point
{
    int intRow;
    int intCol;
    RGBColour recColour;
};

class randomImage
{
public:

    randomImage(); //Default constructor

    //Parameterised constructors
    randomImage(int intRows, int intCols);
    randomImage(int intRows, int intCols, int intRandPoits);

    randomImage(const randomImage& objOriginal);

    int intGetRows() const;
    int intGetCols() const;

    string toPPM();
    void addPoint(int intRow,int intCol );
    void draw();

    //Destructor
    ~randomImage();

private:

    RGBColour generateColour() const;
    bool isPoint(int intRow, int intCol);
    double distance(int r1, int c1, int r2, int c2) const;
    void validatePoint(point& recPoint) const;

    UJImage* _image; //Composition
    vector<point> _points;


};

#endif // RANDOMIMAGE_H_INCLUDED
