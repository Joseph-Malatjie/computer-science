#ifndef UJIMAGE_H_INCLUDED
#define UJIMAGE_H_INCLUDED

#include "CommonLib.h"
#include <string>

using namespace std;

/*
 Colour structure, no behaviour
 therefore PODS (Plain old data structure)
*/
struct RGBColour
{
    int intRed;
    int intGreen;
    int intBlue;
};


/*
    A class is a blueprint for an
    object-oriented type. An object is
    an instance of that type (i.e. a value).
*/
class UJImage
{
public:
    UJImage();
    UJImage(int intRows, int intCols);
    UJImage(const UJImage& objOriginal);

    string toPPM();

    //Accessor functions (getters)
    int getRows() const;
    int getCols() const;
    RGBColour getPixel(int intRow, int intCol) const;

    //Mutator function (setter)
    void setPixel(int intRow, int intCol, RGBColour recColour);

    static const int DEFAULT_ROWS = 600;
    static const int DEFAULT_COLS = 800;
    static const int MAX_SIZE = 100000;

    ~UJImage();
private:
    void enforceRange(int intValue, int intMin, int intMax) const;
    void setup(int intRows, int intCols);
    RGBColour** _pixels;
    int _rows;
    int _cols;
};

#endif // UJIMAGE_H_INCLUDED
