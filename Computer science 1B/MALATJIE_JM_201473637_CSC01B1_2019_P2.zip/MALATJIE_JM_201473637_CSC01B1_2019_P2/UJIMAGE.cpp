#include "UJImage.h"

#include <cstdlib>
#include <iostream>
#include <sstream>

using namespace std;

//Constructor chaining, or just add a utility function
UJImage::UJImage() : UJImage(DEFAULT_ROWS, DEFAULT_COLS)
{
}

UJImage::UJImage(int intRows, int intCols)
{
    setup(intRows, intCols);
}


/*
    Copy constructor will create this object as a duplicate
    instance of an original object. This gets called when
    passed by value, a fixed length array of the class type
    is created, or explicitly via being passed as a constructor
    argument.
*/
UJImage::UJImage(const UJImage& objOriginal)
{
    //Make ourselves the same size as the original
    setup(objOriginal._rows, objOriginal._cols);
    //Copy the contents of the original to us
    for(int r = 0; r < _rows; r++)
    {
        for(int c = 0; c < _cols; c++)
        {
            _pixels[r][c] = objOriginal._pixels[r][c];
        }
    }
}

int UJImage::getRows() const
{
    return _rows;
}

int UJImage::getCols() const
{
    return _cols;
}

RGBColour UJImage::getPixel(int intRow, int intCol) const
{
    enforceRange(intRow, 0, _rows - 1);
    enforceRange(intCol, 0, _cols - 1);

    return _pixels[intRow][intCol];
}

void UJImage::setPixel(int intRow, int intCol, RGBColour recColour)
{
    enforceRange(intRow, 0, _rows - 1);
    enforceRange(intCol, 0, _cols - 1);

    _pixels[intRow][intCol] = recColour;
}

string UJImage::toPPM()
{
     stringstream ssPPM;
     ssPPM << "P3" << endl
           << _cols << ' ' << _rows << endl
           << 255 << endl;
     for(int r = 0; r < _rows; r++)
     {
         for(int c = 0; c < _cols; c++)
         {
             ssPPM << _pixels[r][c].intRed << ' '
                   << _pixels[r][c].intGreen << ' '
                   << _pixels[r][c].intBlue << ' ';
         }
         ssPPM << endl;
     }

     return ssPPM.str();
}

void UJImage::enforceRange(int intValue, int intMin, int intMax) const
{
    if(intValue < intMin)
    {
        cerr << "Out of range: " << intValue << " < " << intMin;
        exit(ERROR_RANGE);
    }

    if(intValue > intMax)
    {
        cerr << "Out of range: " << intValue << " > " << intMax;
        exit(ERROR_RANGE);
    }
}

UJImage::~UJImage()
{
   for(int r = 0; r < _rows; r++)
   {
       delete [] _pixels[r];
   }
   delete [] _pixels;
}

void UJImage::setup(int intRows, int intCols)
{
    enforceRange(intRows, 1, MAX_SIZE);
    enforceRange(intCols, 1, MAX_SIZE);
    _rows = intRows;
    _cols = intCols;

    _pixels = new RGBColour*[_rows];
    for(int r = 0; r < _rows; r++)
    {
        _pixels[r] = new RGBColour[_cols];
        for(int c = 0; c < _cols; c++)
        {
            RGBColour recDefault;
            recDefault.intRed = 0;
            recDefault.intGreen = 0;
            recDefault.intBlue = 0;

            _pixels[r][c] = recDefault;
            //Or __pixels[r][c].intRed =0; etc.
        }
    }
}
