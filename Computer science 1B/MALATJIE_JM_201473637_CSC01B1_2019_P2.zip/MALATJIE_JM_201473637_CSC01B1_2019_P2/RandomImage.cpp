#include "RandomImage.h"
#include <math.h>

randomImage::randomImage()
{
    _image = new UJImage;
}

randomImage::randomImage(int intRows, int intCols)
{
    _image = new UJImage(intRows, intCols);
}

randomImage::randomImage(int intRows, int intCols, int intNumRandPoints) : randomImage(intRows, intCols)
{
    while(intNumRandPoints > 0)
    {
        int r = rangedRandom(0, intGetRows() - 1);
        int c = rangedRandom(0, intGetRows() - 1);

        if(!isPoint(r, c))
        {
            addPoint(r, c);
            intNumRandPoints--;
        }
    }
}

randomImage::randomImage(const randomImage& objOriginal)
{
    _image = new UJImage(*(objOriginal._image));
    _points = objOriginal._points;
}

int randomImage::intGetRows() const
{
    return _image->getRows(); ///Delegation.
}

int randomImage::intGetCols() const
{
    return _image->getCols(); ///Delegation.
}

string randomImage::toPPM()
{
    return _image->toPPM(); ///Delegation.
}

RGBColour randomImage::generateColour() const
{
    RGBColour recColour;
    recColour.intRed =  rangedRandom(0, 255);
    recColour.intGreen = rangedRandom(0, 255);
    recColour.intBlue = rangedRandom(0, 255);

    return recColour;
}

bool randomImage::isPoint(int intRow, int intCol)
{
    for(point p : _points)
    {
        if((p.intRow == intRow) && (p.intCol == intCol))
            return true;
    }
    return false;
}

void randomImage::addPoint(int intRow, int intCol)
{
    point recPoint;
    recPoint.intRow = intRow;
    recPoint.intCol = intCol;
    validatePoint(recPoint);

    _points.push_back(recPoint);
}

void randomImage::validatePoint(point& recPoint) const
{
    unsigned int intMaxNumPoints = intGetRows() * intGetCols();
    if(intMaxNumPoints < _points.size())
    {
        cerr << "Error too many seed points" << endl;
        exit(ERROR_SEED_COUNT);
    }

    bool blnInImage = true;
    if(recPoint.intRow <0) blnInImage = false;
    if(recPoint.intRow >= intGetRows()) blnInImage = false;
    if(recPoint.intCol < 0) blnInImage =  false;
    if(recPoint.intCol >= intGetCols()) blnInImage = false;
    if(!blnInImage)
    {
        cerr << "Error seed point not in image." << endl;
        exit(ERROR_RANGE);
    }

    //Ensure that there is no other seed with the same RGB values.
    RGBColour recColour = generateColour();
    bool blnUnique = _points.size() == 0;
    while(!blnUnique)
    {
        recColour = generateColour();
        for(point p : _points)
        {
            blnUnique = !((p.recColour.intRed == recColour.intRed) &&
                           (p.recColour.intGreen == recColour.intGreen) &&
                           (p.recColour.intBlue == recColour.intBlue));
        }
    }
    recPoint.recColour = recColour;
}

double randomImage::distance(int r1, int c1, int r2, int c2) const
{
    //Return the Euclidean distance.
    return sqrt(pow(r1 - r2, 2) + pow(c1 - c2, 2));
}

void randomImage::draw()
{
    if(_points.size() == 0)
        return;

    for(int r = 0; r < intGetRows(); r++)
    {
        for(int c = 0; c < intGetCols(); c++)
        {
            point recClosest = _points[0];
            double dblMin = distance(r, c, recClosest.intRow, recClosest.intCol);
            for(unsigned int i = 1; i < _points.size(); i++)
            {
                point p = _points[i];
                double dblTemp = distance(r, c, p.intRow, p.intCol);
                if(dblTemp < dblMin)
                {
                    //Update the closest seed point.
                    dblMin = dblTemp;
                    recClosest = p;
                }
            }
            //Use the current seed point's colour to draw the current pixel.
            _image->setPixel(r, c, recClosest.recColour);
        }
    }
}


randomImage::~randomImage()
{
    delete _image; //Life-cycle management.
}

