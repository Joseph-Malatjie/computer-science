#include "RandomImage.h"

#include <ctime>
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char* argv[])
{
    srand(time(nullptr));

    if(argc != 4)
    {
        cerr << "Usage: " << argv[0]
             << " ROWS COLS NUM_RAND_SEED_POINTS"
             << endl;
        exit(ERROR_CMD_ARG_COUNT);
    }

    int intRows = convertToInt(argv[1]);
    int intCols = convertToInt(argv[2]);
    int intPoints = convertToInt(argv[3]);

    randomImage objVoronoi(intRows, intCols, intPoints);
    objVoronoi.draw();

    cout << objVoronoi.toPPM() << endl;
    return 0;
}
