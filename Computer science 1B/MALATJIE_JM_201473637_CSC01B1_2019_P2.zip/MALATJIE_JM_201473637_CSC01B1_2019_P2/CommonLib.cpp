#include "CommonLib.h"

#include <cstdlib>
#include <iostream>
#include <sstream>

using namespace std;

int rangedRandom(int intMin, int intMax)
{
    int intRange = intMax - intMin + 1;
    return rand() % intRange + intMin;
}

int convertToInt(std::string strNumber)
{
    stringstream ssConv;
    ssConv << strNumber;
    int intNumber = 0;
    ssConv >> intNumber;
    if(ssConv.fail())
    {
        cerr << "Error unable to convert "
             << strNumber << " to integer" << endl;
        exit(ERROR_CONVERSION);
    }

    return intNumber;
}
