#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include "UJRowMajorGrid.h"

using namespace std;

#pragma pack(push)
#pragma pack(1)
struct RGBColour
{
    int intRed;
    int intGreen;
    int intBlue;
};
#pragma pack(pop)

void saveToCSV(string strFilename, UJRowMajorGrid<RGBColour> objGrid)
{
    ofstream flOut(strFilename);
    for(int r = 0; r < objGrid.getRows(); r++)
    {
        for(int c = 0; c < objGrid.getCols(); c++)
        {
            flOut << objGrid(r, c).intRed << ", "
                  << objGrid(r, c).intGreen << ", "
                  << objGrid(r, c).intBlue << ", ";
        }
        flOut << endl;
    }
    flOut.close();
}

void removeCommas(string& strLine)
{
    for(char& c : strLine)
    {
        if(c == ',')
        {
            c = ' ';
        }
    }
}

UJRowMajorGrid<RGBColour> loadFromCSV(string strFilename)
{
    ifstream flIn(strFilename);
    string strLine = "";
    vector<vector<RGBColour>> vectPixels;
    while(getline(flIn, strLine))
    {
        removeCommas(strLine);
        vector<RGBColour> vectRow;
        stringstream ssLine;
        ssLine << strLine;
        RGBColour recPixel;
        while(ssLine >> recPixel.intRed
                      >> recPixel.intGreen
                      >> recPixel.intBlue)
        {
            vectRow.push_back(recPixel);
        }
        vectPixels.push_back(vectRow);
    }
    flIn.close();

    int intRows = vectPixels.size();
    int intCols = vectPixels[0].size();
    UJRowMajorGrid<RGBColour> objGrid(intRows, intCols);
    for(int r = 0; r < objGrid.getRows(); r++)
    {
        for(int c = 0; c < objGrid.getCols(); c++)
        {
            objGrid(r, c) = vectPixels[r][c];
        }
    }

    return objGrid;
}

void saveToDAT(string strFilename, UJRowMajorGrid<RGBColour> objGrid)
{
    fstream flOut(strFilename, ios::out | ios::binary | ios::app);
    for(int r = 0; r < objGrid.getRows(); r++)
    {
        for(int c = 0; c < objGrid.getCols(); c++)
        {
            RGBColour recPixel = objGrid(r,c);
            flOut.write(reinterpret_cast<char*>(&recPixel),
            sizeof(RGBColour));
        }
    }
    flOut.close();
}

int countRecords(string strFilename)
{
    fstream flIn(strFilename, ios::in | ios::binary);
    flIn.seekg(0, ios::end);
    int intBytes = flIn.tellg();
    flIn.close();
    return intBytes / sizeof(RGBColour);
}

RGBColour loadFromDATByIndex(string strFilename, int intIndex)
{
    fstream flIn(strFilename, ios::in | ios::binary);
    RGBColour recPixel;
    flIn.seekg(intIndex * sizeof(RGBColour), ios::beg);
    flIn.read(reinterpret_cast<char*>(&recPixel),
    sizeof(RGBColour));
    flIn.close();

    return recPixel;
}

int countColoursFromDAT(string strFilename, RGBColour recColour)
{
    int intRecords = countRecords(strFilename);
    int intCount = 0;
    for(int i = 0; i < intRecords; i++)
    {
        RGBColour recPixel = loadFromDATByIndex(strFilename, i);
        if((recPixel.intRed == recColour.intRed) &&
           (recPixel.intGreen == recColour.intGreen) &&
           (recPixel.intBlue == recColour.intBlue))
        {
            intCount++;
        }
    }

    return intCount;
}

int rangedRandom(int intMin, int intMax)
{
    int intRange = intMax - intMin + 1;
    return rand() % intRange + intMin;
}

UJRowMajorGrid<RGBColour> generateRandomPixelGrid(int intRows, int intCols)
{
    UJRowMajorGrid<RGBColour> objGrid(intRows, intCols);
    for(int r = 0; r < objGrid.getRows(); r++)
    {
        for(int c = 0; c < objGrid.getCols(); c++)
        {
            objGrid(r, c).intRed = rangedRandom(0, 255);
            objGrid(r, c).intGreen = rangedRandom(0, 255);
            objGrid(r, c).intBlue = rangedRandom(0, 255);
        }
    }

    return objGrid;
}

void printGrid(UJRowMajorGrid<RGBColour> objGrid)
{
    for(int r = 0; r < objGrid.getRows(); r++)
    {
        for(int c = 0; c < objGrid.getCols(); c++)
        {
            cout << "(" << objGrid(r, c).intRed << ", "
                 << objGrid(r, c).intGreen << ", "
                 << objGrid(r, c).intBlue << ") ";
        }
        cout << endl;
    }
}
