#ifndef UJROWMAJORGRID_H_INCLUDED
#define UJROWMAJORGRID_H_INCLUDED

#include <iostream>
#include <vector>

using namespace std;

enum StatusCode
{
 SUCCESS,
 ERROR_RANGE
};

struct Coordinate
{
    int intRow;
    int intCol;
};

template <typename T>
class UJRowMajorGrid
{
    public:
    //Constructors
    UJRowMajorGrid();
    UJRowMajorGrid(int intRows, int intCols);
    UJRowMajorGrid(const UJRowMajorGrid<T>& objOriginal);

    //Overloaded operators

    UJRowMajorGrid<T>& operator=(const UJRowMajorGrid<T>& objRHS);

    bool operator==(const UJRowMajorGrid<T>& objRHS);

    bool operator!=(const UJRowMajorGrid<T>& objRHS);

    template <typename T1>
    friend ostream& operator<<(ostream& sLHS, const UJRowMajorGrid<T1>& objRHS);

    T& operator[](int intIndex);

    T& operator()(int intRow, int intCol);

    //Class constants

    static const int MAX_SIZE = 100000000;
    static const int MIN_SIZE = 1;
    static const int DEFAULT_ROWS = 4;
    static const int DEFAULT_COLS = 3;

    //Not actually required by the question
    T getValue(int intRow, int intCol) const;
    //Required for type to be useful
    int getRows() const;
    int getCols() const;

    //Mutator member functions
    //Not actually required by the question
    void setValue(int intRow, int intCol, T tValue);

    //Destructor
    ~UJRowMajorGrid();
    private:
    //Utility member functions
    void enforceRange(int intValue, int intMin, int intMax) const;
    void setup(int intRows, int intCols);
    void freeState();
    void copyState(const UJRowMajorGrid<T>& objOriginal);

    vector<Coordinate> _dimensionMap;

    int _rows;
    int _cols;

    T** _values;
};

#include "UJRowMajorGrid.imp"

#endif // UJROWMAJORGRID_H_INCLUDED
