#include <iostream>
#include <time.h>
#include "UJRowMajorGrid.h"

using namespace std;

int main()
{
    cout << "Generating \"random\" image..." << endl;
    srand(42);
    UJRowMajorGrid<RGBColour > objGrid = generateRandomPixelGrid(10, 6);
    printGrid(objGrid);
    cout << endl;

    cout << "Saving to CSV" << endl;
    saveToCSV("Image.csv", objGrid);
    cout << endl;

    cout << "Loading from CSV" << endl;
    UJRowMajorGrid<RGBColour > objGrid2 = loadFromCSV("Image.csv");
    printGrid(objGrid2);
    cout << endl;

    cout << "Saving to binary file of records" << endl;
    saveToDAT("Image.dat", objGrid);
    cout << "Number of records: " << countRecords("Image.dat") << endl;

    RGBColour recSearch ;
    cout << "Enter red, green, and blue values (0 - 255)" << endl;
    cin >> recSearch .intRed >> recSearch .intGreen >> recSearch .intBlue;
    cout << "Number of pixels with that colour: "
        << countColoursFromDAT("Image.dat", recSearch ) << endl;

    return 0;

}
